

<?php $__env->startSection('title'); ?> Customer Update <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Customer Update <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?>  <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.create')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="c_id" value="<?php echo e($customer->id); ?>">
                                        <div class="form-group row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Name</label>
                                            <div class="col-md-10">
                                                <input class="form-control" name="name" type="text" placeholder="Enter name" value="<?php echo e($customer->name); ?>" id="example-text-input">
                                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label for="example-email-input" class="col-md-2 col-form-label">Email</label>
                                            <div class="col-md-10">
                                                <input class="form-control" name="email" type="email" value="<?php echo e($customer->email); ?>" placeholder="Enter email" id="example-email-input">
                                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-search-input" class="col-md-2 col-form-label">Address</label>
                                            <div class="col-md-10">
                                                <input class="form-control" value="<?php echo e($customer->address); ?>" type="text" placeholder="Enter Address" name="address" id="example-search-input">
                                                <?php echo e($errors->first('address')); ?>

                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label for="example-tel-input" class="col-md-2 col-form-label">Telephone</label>
                                            <div class="col-md-10">
                                                <input class="form-control" name="phoneno" type="tel" value="<?php echo e($customer->phoneno); ?>" placeholder="Enter phone no" id="example-tel-input">
                                                <?php echo e($errors->first('phoneno')); ?>

                                            </div>
                                        </div>
                                        
                                        <!-- <div class="form-group row">
                                            <label for="example-password-input" class="col-md-2 col-form-label">Password</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="password" placeholder="Enter password" id="example-password-input">
                                            </div>
                                        </div> -->
                                    
                                        <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Update</button>
                                    </div>

                                   </form>

                                    </div>
                                </div>
                            </div> <!-- end col -->

                        </div>
                        <!-- end row -->

                        <!-- end row -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/edit-customer.blade.php ENDPATH**/ ?>