

<?php $__env->startSection('title'); ?> Phone Service Edit <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Phone Service Edit <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?><?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <div class="row">
                              <?php if(Session::has('message')): ?>
                              <div class="col-12">
                                  <?php echo Session::get('message'); ?>

                              </div>
                              <?php endif; ?>
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.service.update',$phoneService->id)); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>



                                            <div class="form-group row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Serive Name</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" name="service_name" type="text" placeholder="Enter service name" value="<?php echo e($phoneService->service_name); ?>"  id="example-text-input">
                                                    <span class="text-danger"><?php echo e($errors->first('service_name')); ?></span>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label">Service Image</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="file" name="image" id="profile-img">
                                                    <span class="text-danger"><?php echo e($errors->first('code')); ?></span>

                                                <div id="imagShow">
                                                    <img src="<?php echo e(asset('storage/service/'.$phoneService->image)); ?> " id="profile-img-tag" width="150px" height="100px">
                                                </div>
                                                <div class="gallery">
                                                </div>
                                            </div>
                                            </div>
                                        <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                    </div>

                                   </form>

                                    </div>
                                </div>
                            </div> <!-- end col -->

                        </div>
                        <!-- end row -->

                        <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(function() {
$('.selectpic').select2();
});

$(function() {
    // Multiple images preview in browser
    var imagesPreview = function(input, placeToInsertImagePreview) {

        if (input.files) {
            $(".gallery").empty();
            $('#imagShow').hide();
            var filesAmount = input.files.length;

            for (i = 0; i < filesAmount; i++) {
                var reader = new FileReader();

                reader.onload = function(event) {
                    $($.parseHTML('<img>')).attr('src', event.target.result).appendTo(placeToInsertImagePreview);
                }

                reader.readAsDataURL(input.files[i]);
            }
        }

    };


    $('#profile-img').on('change', function() {
        imagesPreview(this, 'div.gallery');
    });
});
</script>

<script>
    function getModel(event)
    {
        var id = $(event).val();
        $.ajax({
        url: "<?php echo e(url('admin/accessory/getModels')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
        },

       });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/productService/edit.blade.php ENDPATH**/ ?>