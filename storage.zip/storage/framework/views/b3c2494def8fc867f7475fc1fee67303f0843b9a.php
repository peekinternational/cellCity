          <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div>
            <div class="single-answer-component-wrapper model">
              <div class="fade-on-mount normal-elemnt-active">
                <button class="answer-content" onclick="getrepairTypes('<?php echo e($model->id); ?>','<?php echo e($model->model_name); ?>')" ><label for="<?php echo e($model->model_name); ?>"><?php echo e($model->model_name); ?></label></button>
                <!-- <input type="radio" id="<?php echo e($model->model_name); ?>"  name="phone_model" class="hidden"> -->
              </div>
            </div>
          </div>

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/models.blade.php ENDPATH**/ ?>