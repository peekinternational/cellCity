
<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend-assets/css/custom.css')); ?>">
<style>
#slider-container{
    width:260px;
    margin:10px;
}
</style>
<?php $__env->startSection('content'); ?>
<!--Page Title-->
<!-- <section class="page-title" style="background-image: url(frontend-assets/images/background/3.jpg);">
	<div class="auto-container">
    	<ul class="bread-crumb">
            <li><a href="index-2.html">Home</a></li>
            <li class="active">Shop</li>
        </ul>
    	<h1>Shop</h1>
    </div>
</section> -->
<!--End Page Title-->
<!--Shop Section-->

<section class="shop-section shop-page">
	<div class="auto-container">
    	<!--Sort By-->
      <h3 class="_3n9_eRVa OCgW6kA95RgHDgyrkt-3F">Buy Phones</h3>
      <div data-test="carrier-filters" class="_37xvF8QgM_NvGXx3HcYuJ2">
        <h3 class="_2B3yYCfeT_icE3-czlIZpA _24G233rJGINfRvQy6b013n fp6kZqTX1H1PmSmQgEG_U _6d15qX6LWY1Hi6Z98JjWP">I need a phone that works with ...</h3>
        <div class="a-cell row" data-v-2b8789a2="">
          <div class="a-cell xs-12 md-9 _114juaGTKcgQcFQKoPzirv" data-v-2b8789a2="">

            <?php $__empty_1 = true; $__currentLoopData = CityClass::phoneServices(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phoneservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <label data-qa="0  AT&amp;T-checkbox-label" data-test="checkbox-AT&amp;T" class="_2dZyu6FGSL9sjsXTxboSwL _3FFHvPz39UA03ZA4Mv13pX" data-v-2b8789a2="">
              <input data-test="input" name="service" type="checkbox" class="_2X8Raljpwo5umcD_HYzefT getPhoneService" value="<?php echo e($phoneservice->id); ?>" onclick="phoneService()">
              <span data-test="checkbox-span" class="_2Q2hhB3NvM2sAldZj6fGXU"></span>
              <span class="L5UAN0lD0YKf94yOvozYH">
                <div class="_2QOueHT- HWdZT4KgOk8JhBI9OzX9g"><!---->
                    <img src="<?php echo e(asset('storage/service/'.$phoneservice->image)); ?>" alt="AT&amp;T" loading="lazy" class="wrAXteFB">
                </div>
              </span>
            </label>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    Ops No data.....
            <?php endif; ?>

          </div>
          <div class="a-cell xs-12 md-3" data-v-2b8789a2="">
            <div class="axop9d4ghf_ZiU7FQc-M8 baseselect-wrapper _2u25sfWmf6NUCbJ_StTs_r" data-v-2b8789a2=""><!---->
              <select id="simlock" data-formgroup-element="" onchange="getUnlocked(this)" data-test="simlock" name="simlock" class="_3Iq8JGYZpyTj97wvi5Wyu7 eUlOsp7XbB9G1L8SEMMpU baseselect-field">
                <option value="">All</option>
                <option value="Locked">Locked Only</option>
                <option value="Unlocked">Unlocked only </option>
              </select>
              <label data-test="baseselect-label" for="simlock" class="PSXfa64BhcchUXTYm8jxr _2Y-fYnDKPqxkYV__KtgvWD baseselect-label">
                
              </label>
              <div class="_3CTJYWu3hsWyWna_ZcsF5I">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 443.9 476.5" data-test="baseselect-icon" class="-S5BM_soVHE3yxeKelL2Q _1-GUUYIHoGjHHKudYw6-sr"><path d="M220.2 355.7c-3.1 0-6.1-1.2-8.5-3.5L9.1 149.6c-4.7-4.7-4.7-12.3 0-17 4.7-4.7 12.3-4.7 17 0l194.1 194.1 197-197c4.7-4.7 12.3-4.7 17 0 4.7 4.7 4.7 12.3 0 17L228.7 352.2c-2.4 2.3-5.4 3.5-8.5 3.5z"></path></svg>
              </div>
            </div>
          </div>
        </div>
      </div>

        <!-- <div class="items-sorting">
            <div class="row clearfix">
                <div class="results-column col-md-6 col-sm-6 col-xs-12">
                    <h4>Showing 1–8 of 23 results</h4>
                </div>
                <div class="select-column pull-right col-md-3 col-sm-4 col-xs-12">
                    <div class="form-group">
                        <select name="sort-by">
                            <option>Default Sorting</option>
                            <option>By Order</option>
                            <option>By Price</option>
                        </select>
                    </div>
                </div>
            </div>
        </div> -->

    	<div class="row clearfix">
        <div class="col-md-3 sidebar-filter">
          <ul class="_1PyjTAdMUxZV6zOWToeiGU">
            <li class="_2LiMhAnX4MDtEL5YEDIdLy">
              <span class="_2RGsPtNo">Price</span>

                <div id="slider-container"></div>

                    <p>
                    <label for="amount">Price range:</label>
                    <input type="text" id="amount" style="border: 0; color: #00bfa5; font-weight: bold;" />
                    </p>


                    <div id="slider-range"></div>



             </li>

            <li class="_2LiMhAnX4MDtEL5YEDIdLy">
              <h3 class="_2RGsPtNo">Brand</h3>
              <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t">
                <li class="_33pDOgQ80LhcEmJTGXNM3U">
                  <div>
                    <input id="brand-reset" type="checkbox" name="brand_name" data-test="facet-reset" class="_3wvnh-Qn">
                    <label for="brand-reset" class="_33K8eTZu">
                      <div class="_3S4CObWg">
                        <div class="_2OVE0h6V"></div>
                        <div class="_3xAYCg9N">
                          <svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg>
                        </div>
                      </div>
                      <div class="TRSMTVTh">
                        <span class="_28IelIKC">
                          <span class="_28IelIKC">All</span>
                        </span>
                      </div> <!----> <!---->
                    </label>
                  </div>
                </li>
                <?php $__currentLoopData = CityClass::brands(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U">
                  <div>
                    <input id="brand-<?php echo e($brand->id); ?>" type="checkbox" name="brand_name" data-test="facet- <?php echo e(ucwords($brand->brand_name)); ?>" class="_3wvnh-Qn getBrandId" value="<?php echo e($brand->id); ?>" onclick="getBrand(<?php echo e($brand->id); ?>)">
                    <label for="brand-<?php echo e($brand->id); ?>" class="_33K8eTZu">
                      <div class="_3S4CObWg">
                        <div class="_2OVE0h6V"></div>
                        <div class="_3xAYCg9N">
                          <svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg>
                        </div>
                      </div>
                      <div class="TRSMTVTh">
                        <span class="_28IelIKC">
                          <span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k"><?php echo e(ucwords($brand->brand_name)); ?></span><span></span>
                        </span>
                      </div>
                    </label>
                  </div>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <span class="_3JZtHpVH kdWBx8BsOXOeHlX8MCQf_">
                  <button data-test="facet-toggler" class="_3wCdvNLg s1Zi9DG5">See more</button>
                </span>
              </ul>
            </li>
              <li class="_2LiMhAnX4MDtEL5YEDIdLy"><h3 class="_2RGsPtNo">
                  Model
                </h3>
                <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t" id="modelsss">
                    <li class="_33pDOgQ80LhcEmJTGXNM3U"><div><input id="model-reset" type="checkbox" checked="checked" data-test="facet-reset" class="_3wvnh-Qn"> <label for="model-reset" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC">
                    All
                  </span></span></div> <!----> <!----></label></div></li>

                  <?php $__currentLoopData = CityClass::allModels(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $models): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U">

                          <input id="<?php echo e($models->id); ?>" type="checkbox" name="models_name" data-test="facet-<?php echo e($models->brand->brand_name ?? ''); ?>  <?php echo e($models->model_name ?? ''); ?>" class="_3wvnh-Qn  getModelId"  value="<?php echo e($models->id); ?>" onclick="getModels(<?php echo e($models->id); ?>)">
                           <label for="<?php echo e($models->id); ?>" class="_33K8eTZu">
                            <div class="_3S4CObWg">
                               <div class="_2OVE0h6V"></div>
                               <div class="_3xAYCg9N">
                                   <svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg">
                                    <path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg>
                                    </div>
                                </div>
                                    <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                                        <?php echo e(ucwords($models->brand->brand_name) ?? ''); ?>  <?php echo e(ucwords($models->model_name) ?? ''); ?>

                                    </span>
                                    </span>
                                </div> <!----> <!---->
                            </label>

                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                  <span class="_3JZtHpVH kdWBx8BsOXOeHlX8MCQf_">
                      <button data-test="facet-toggler" class="_3wCdvNLg s1Zi9DG5">
                
                see more
              </button></span></ul></li>

              <li class="_2LiMhAnX4MDtEL5YEDIdLy"><h3 class="_2RGsPtNo">
                  New & Old
                </h3> <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t"><li class="_33pDOgQ80LhcEmJTGXNM3U"><div><input id="backbox_grades_list-reset" type="checkbox" checked="checked" data-test="facet-reset" class="_3wvnh-Qn"> <label for="backbox_grades_list-reset" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentType" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC">
                    All
                  </span></span></div> <!----> <!----></label></div></li>


                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="backbox_grades_list-10 new" name="type"  type="checkbox" value="new"  data-test="facet-new" class="_3wvnh-Qn gettype" onclick="getNewOld()" >
                       <label for="backbox_grades_list-10 new" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentType" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    New
                  </span> <!----></span></div> <!----> <!----></label></div></li>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="backbox_grades_list-11 old"  name="type" type="checkbox"  value="old" data-test="facet-old" class="_3wvnh-Qn gettype" onclick="getNewOld()">
                      <label for="backbox_grades_list-11 old" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentType" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    Old
                  </span> <!----></span></div> <!----> <!----></label></div></li>

                </ul></li>


              <li class="_2LiMhAnX4MDtEL5YEDIdLy"><h3 class="_2RGsPtNo">
                  Condition
                </h3> <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t"><li class="_33pDOgQ80LhcEmJTGXNM3U"><div><input id="backbox_grades_list-reset" type="checkbox" checked="checked" data-test="facet-reset" class="_3wvnh-Qn"> <label for="backbox_grades_list-reset" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC">
                    All
                  </span></span></div> <!----> <!----></label></div></li>


                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="backbox_grades_list-10 Excellent" name="condition"  type="checkbox" value="excellent"  data-test="facet-Excellent" class="_3wvnh-Qn getCondition" onclick="getCondition()" >
                       <label for="backbox_grades_list-10 Excellent" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    Excellent
                  </span> <!----></span></div> <!----> <!----></label></div></li>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="backbox_grades_list-11 Good"  name="condition" type="checkbox"  value="good" data-test="facet-Good" class="_3wvnh-Qn getCondition" onclick="getCondition()">
                      <label for="backbox_grades_list-11 Good" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    Good
                  </span> <!----></span></div> <!----> <!----></label></div></li>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="backbox_grades_list-12 Fair" name="condition"  type="checkbox" value="fair"  data-test="facet-Fair" class="_3wvnh-Qn getCondition" onclick="getCondition()">
                      <label for="backbox_grades_list-12 Fair" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    Fair
                  </span> <!----></span></div> <!----> <!----></label></div></li>
                  <!---->
                </ul></li>



                  <li class="_2LiMhAnX4MDtEL5YEDIdLy"><h3 class="_2RGsPtNo">
                  Phone Services Provider
                </h3> <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t"><li class="_33pDOgQ80LhcEmJTGXNM3U"><div><input id="compatible_carriers_facet-reset" type="checkbox" checked="checked" data-test="facet-reset" class="_3wvnh-Qn"> <label for="compatible_carriers_facet-reset" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC">
                    All
                  </span></span></div> <!----> <!----></label></div></li>
                  <?php $__empty_1 = true; $__currentLoopData = CityClass::phoneServices(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $phoneservice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="<?php echo e($phoneservice->id); ?>" name="service" type="checkbox" data-test="facet-<?php echo e($phoneservice->service_name); ?>" class="_3wvnh-Qn getPhoneService" value="<?php echo e($phoneservice->id); ?>" onclick="phoneService()">
                       <label for="<?php echo e($phoneservice->id); ?>" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                     <?php echo e($phoneservice->service_name); ?>

                  </span> </span></div> <!----> <!----></label></div></li>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>

                  <?php endif; ?>


                <span class="_3JZtHpVH kdWBx8BsOXOeHlX8MCQf_"><button data-test="facet-toggler" class="_3wCdvNLg s1Zi9DG5">
                See more
              </button></span></ul></li>

              <li class="_2LiMhAnX4MDtEL5YEDIdLy"><h3 class="_2RGsPtNo">
                  Locked or Unlocked
                </h3> <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t"><li class="_33pDOgQ80LhcEmJTGXNM3U"><div><input id="sim_lock_state-reset" type="checkbox" checked="checked" data-test="facet-reset" class="_3wvnh-Qn"> <label for="sim_lock_state-reset" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC">
                    All
                  </span></span></div> <!----> <!----></label></div></li>
                   <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                       <input id="sim_lock_state-Locked" type="checkbox" data-test="facet-Locked" class="_3wvnh-Qn getLocked" value="Locked" onclick="getLocked()">
                       <label for="sim_lock_state-Locked" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    Locked only
                  </span> </span></div> <!----> <!----></label></div></li>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="sim_lock_state-Unlocked only" type="checkbox" data-test="facet-Unlocked" class="_3wvnh-Qn getLocked" value="Unlocked" onclick="getLocked()">
                      <label for="sim_lock_state-Unlocked only" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    Unlocked only
                  </span> </span></div> <!----> <!----></label></div></li> <!----></ul></li>
                <li class="_2LiMhAnX4MDtEL5YEDIdLy"><h3 class="_2RGsPtNo">
                  Storage (GB)
                </h3> <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t"><li class="_33pDOgQ80LhcEmJTGXNM3U"><div><input id="storage-reset" type="checkbox" checked="checked" data-test="facet-reset" class="_3wvnh-Qn"> <label for="storage-reset" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC">
                    All
                  </span></span></div> <!----> <!----></label></div></li>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="storage-2000 2 GB" type="checkbox" data-test="facet-1 GB" class="_3wvnh-Qn getStorage" value="2 GB" onclick="getStorage()">
                        <label for="storage-2000 2 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                     2 GB
                  </span> </span></div> <!----> <!----></label></div></li>

                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="storage-4000 4 GB" type="checkbox" data-test="facet-4 GB" class="_3wvnh-Qn getStorage" value="4 GB" onclick="getStorage()">
                         <label for="storage-4000 4 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    4 GB
                  </span> </span></div> <!----> <!----></label></div></li>

                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="storage-8000 8 GB" type="checkbox" data-test="facet-8 GB" class="_3wvnh-Qn getStorage" value="8 GB" onclick="getStorage()">
                        <label for="storage-8000 8 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    8 GB
                  </span> </span></div> <!----> <!----></label></div></li>

                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="storage-16000 16 GB" type="checkbox" data-test="facet-16 GB" class="_3wvnh-Qn  getStorage" value="16 GB" onclick="getStorage()">
                        <label for="storage-16000 16 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    16 GB
                  </span> </span></div> <!----> <!----></label></div></li>

                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="storage-32000 32 GB" type="checkbox" data-test="facet-32 GB" class="_3wvnh-Qn  getStorage" value="32 GB" onclick="getStorage()">
                         <label for="storage-32000 32 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    32 GB
                  </span></span></div> <!----> <!----></label></div></li>

                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                      <input id="storage-64000 64 GB" type="checkbox" data-test="facet-62 GB" class="_3wvnh-Qn  getStorage" value="64 GB" onclick="getStorage()" >
                         <label for="storage-64000 64 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                    64 GB
                  </span> </span></div> <!----> <!----></label></div></li>
                  <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                    <input id="storage-128000 128 GB" type="checkbox" data-test="facet-128 GB" class="_3wvnh-Qn  getStorage" value="128 GB" onclick="getStorage()" >
                       <label for="storage-128000 128 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                  128 GB
                </span> </span></div> <!----> <!----></label></div></li>
                <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                    <input id="storage-256000 256 GB" type="checkbox" data-test="facet-256 GB" class="_3wvnh-Qn  getStorage" value="256 GB" onclick="getStorage()" >
                       <label for="storage-256000 256 GB" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                  256 GB
                </span> </span></div> <!----> <!----></label></div></li>

                   <span class="_3JZtHpVH kdWBx8BsOXOeHlX8MCQf_"><button data-test="facet-toggler" class="_3wCdvNLg s1Zi9DG5">
                See more
              </button></span></ul></li>
              </ul>
        </div>
        <div class="col-md-9">
          <div class="row" id="filter">
            <!--Shop Item-->


            <!--Shop Item-->
             <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $color = App\Models\ProductColor::where('product_id',$product->id)->first();
                $storage = App\Models\ProductStorage::where('color_id',$color->id)->first();
                $model = App\Models\Pmodel::where('id',$product->model_id)->first();
                $images = App\Models\ProductImage::where('product_id',$product->id)->first();
                // dd($images);
                $condition = App\Models\ProductCondition::where('storage_id',$storage->id)->first();
                ?>


            <div class="shop-item col-md-4 col-sm-6 col-xs-12">
              <div class="inner-box">
                  <?php if(Auth::user()): ?>

                     <?php if(CityClass::checkWishlist($product->id) == "1"): ?>
                     <a href="#" onclick="undoWishlist(<?php echo e($product->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#ff0707"></i></a>
                     <?php else: ?>
                     <a href="#" onclick="wishlist(<?php echo e($product->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#adadad"></i></a>
                     <?php endif; ?>
                   <?php else: ?>
                   <a href="#" onclick="wishlist(<?php echo e($product->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#adadad"></i></a>
                  <?php endif; ?>



                  <figure class="image-box">

                   <a href="<?php echo e(route('product.details',$product->id)); ?>"><img src="<?php echo e(asset('storage/images/products/'.$images->image ?? '' )); ?>" alt="" /></a>

                </figure>
                  <!--Lower Content-->
                  <div class="lower-content">
                    <h3><a href=""><?php echo e($model->brand->brand_name ?? ''); ?>  <?php echo e($model->model_name ?? ''); ?> </a></h3>
                    <div> <span><?php echo e($storage->storage  ?? ''); ?> -<?php echo e($color->color_name ?? ''); ?> - <?php echo e($product->locked ?? ''); ?></span> </div>
                      <span>
                      Warranty: <?php echo e($product->warranty ?? ''); ?>

                      </span>
                      <div class="brand-imgs">
                          <?php $__currentLoopData = $product->service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <div class="brand">
                            <img src="<?php echo e(asset('storage/service/'.$service->image)); ?>">
                          </div>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                      <div>Starting from</div>
                      <div class="price">
                      <strong>$<?php echo e($condition->price ?? ''); ?>.00</strong> <del>$<?php echo e($product->original_price ?? ''); ?></del></div>
                      <!-- <a href="" class="cart-btn theme-btn btn-style-two">Add to cart</a> -->
                  </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


          </div>
          <div class="text-center">
        	<!-- Styled Pagination -->
            <div class="styled-pagination">
                <?php echo e($products->links('vendor.pagination.custom')); ?>

            </div>
        </div>
        </div>
      </div>



    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>


    function getBrand(id){
        //   alert('asdasd');
        var id = id;
       var  brand = [];

       $(".getCondition").each(function(){
        if($(this).is(":checked")){
            $('.getCondition').prop('checked', false);
        }
       });
      ;
       $(".getStorage").each(function(){
                if($(this).is(":checked")){
                    $('.getStorage').prop('checked', false);
                }
            });

       $(".getBrandId").each(function(){
        if($(this).is(":checked")){
            brand.push($(this).val());
        }
       });

       $('input:checkbox[name=models_name]').each(function()
            {
                if($(this).is(':checked'))
                $('.getModelId').prop('checked', false);
            //    console.log(selectedBrand);
            });

       var getbrand = brand.toString();
            // console.log(getbrand);
       $.ajax({
        url: "<?php echo e(url('getBrandFilter')); ?>",
        type:"get",
        dataType: "json",
        data:"brand=" + brand,

        success:function(response){
          console.log(response);
             var mode= JSON.stringify(response)
            var brnd = JSON.parse(mode);
            console.log(brnd);
          $('#modelsss').html(response.models);
          $('#filter').html(response.brands);

        //   $('#exampleModal'+id).modal('show');
        },


       });

      }

      function getModels(id){
        //   alert('asdasd');
        // var id = id;

        $(".getCondition").each(function(){
        if($(this).is(":checked")){
            $('.getCondition').prop('checked', false);
        }
       });
        $(".getBrandId").each(function(){
        if($(this).is(":checked")){

              $('.getBrandId').prop('checked', false);
        }
       });
         $(".getStorage").each(function(){
                if($(this).is(":checked")){
                    $('.getStorage').prop('checked', false);
                }
            });
         var selectedModel =[];
        $('input:checkbox[name=models_name]').each(function()
            {
                if($(this).is(':checked'))
                selectedModel.push($(this).val());
            //    console.log(selectedBrand);
            });

            var selectedModel = selectedModel.toString();
        // console.log($('input[name="brand_name"]:checked').serialize());

        var  models = [];
       $(".getModelId").each(function(){
        if($(this).is(":checked")){
            models.push($(this).val());
        }
       });

       var getmodels = models.toString();
            // console.log(getmodels);
       $.ajax({
        url: "<?php echo e(url('getBrandFilter')); ?>",
        type:"get",
        dataType:"html",
        data:{model:getmodels,selectedModel:selectedModel},

        success:function(response){
          console.log(response);
          $('#filter').html(response);
        //   $('#exampleModal'+id).modal('show');
        },


       });

      }

      function getCondition(){

        var selectedModel =[];
        $('input:checkbox[name=models_name]').each(function()
            {
                if($(this).is(':checked'))
                selectedModel.push($(this).val());
            //    console.log(selectedBrand);
            });

            var selectedModel = selectedModel.toString();
          console.log(selectedModel);


        var  getCondition = [];
       $(".getCondition").each(function(){
        if($(this).is(":checked")){
          getCondition.push($(this).val());
        }
       });

       var getCondition = getCondition.toString();
            console.log(getCondition);
       $.ajax({
        url: "<?php echo e(url('getBrandFilter')); ?>",
        type:"get",
        dataType:"html",
        data:{getCondition:getCondition,selectedModel:selectedModel},

        success:function(response){
          console.log(response);
          $('#filter').html(response);
        //   $('#exampleModal'+id).modal('show');
        },

       });

      }
      function getNewOld(){

        var selectedModel =[];
        $('input:checkbox[name=models_name]').each(function()
            {
                if($(this).is(':checked'))
                selectedModel.push($(this).val());
            //    console.log(selectedBrand);
            });

            var selectedModel = selectedModel.toString();
          console.log(selectedModel);


        var  gettype = [];
       $(".gettype").each(function(){
        if($(this).is(":checked")){
            gettype.push($(this).val());
        }
       });

       var gettype = gettype.toString();
            console.log(getCondition);

       $.ajax({
        url: "<?php echo e(url('getBrandFilter')); ?>",
        type:"get",
        dataType:"html",
        data:{gettype:gettype,selectedModel:selectedModel},

        success:function(response){
          console.log(response);
          $('#filter').html(response);
        //   $('#exampleModal'+id).modal('show');
        },

       });

      }
      function getStorage()
        {
            var selectedModel =[];
            $('input:checkbox[name=models_name]').each(function()
                {
                    if($(this).is(':checked'))
                    selectedModel.push($(this).val());
                //    console.log(selectedBrand);
                });

            var selectedModel = selectedModel.toString();

          console.log(selectedModel);
            var getStorage= [];
            $(".getStorage").each(function(){
                if($(this).is(":checked")){
                    getStorage.push($(this).val());
                }
            });

            var getStorage = getStorage.toString();
                    console.log(getStorage);
            $.ajax({
                url: "<?php echo e(url('getBrandFilter')); ?>",
                type:"get",
                dataType:"html",
                data:{getStorage:getStorage,selectedModel:selectedModel},

                success:function(response){
                console.log(response);
                $('#filter').html(response);
                //   $('#exampleModal'+id).modal('show');
                },

            });
        }

        function getLocked()
        {

            var selectedModel =[];
            $('input:checkbox[name=models_name]').each(function()
                {
                    if($(this).is(':checked'))
                    selectedModel.push($(this).val());
                //    console.log(selectedBrand);
                });

            var selectedModel = selectedModel.toString();

          console.log(selectedModel);
            var getLocked= [];
            $(".getLocked").each(function(){
                if($(this).is(":checked")){
                    getLocked.push($(this).val());
                }
            });

            var getLocked = getLocked.toString();
                    console.log(getLocked);
            $.ajax({
                url: "<?php echo e(url('getBrandFilter')); ?>",
                type:"get",
                dataType:"html",
                data:{getLocked:getLocked,selectedModel:selectedModel},
                success:function(response){
                console.log(response);
                $('#filter').html(response);
                //   $('#exampleModal'+id).modal('show');
                },

            });
        }

        function getUnlocked(event)
        {
              var getLocked = $(event).val();

              var selectedModel =[];
            $('input:checkbox[name=models_name]').each(function()
                {
                    if($(this).is(':checked'))
                    selectedModel.push($(this).val());
                //    console.log(selectedBrand);
                });

            var selectedModel = selectedModel.toString();

              $.ajax({
                url: "<?php echo e(url('getBrandFilter')); ?>",
                type:"get",
                dataType:"html",
                data:{getLocked:getLocked,selectedModel:selectedModel},
                success:function(response){
                console.log(response);
                $('#filter').html(response);
                //   $('#exampleModal'+id).modal('show');
                },

            });

        }

       function phoneService()
       {
                    var selectedModel =[];
                    $('input:checkbox[name=models_name]').each(function()
                        {
                            if($(this).is(':checked'))
                            selectedModel.push($(this).val());
                        //    console.log(selectedBrand);
                        });

                        var selectedModel = selectedModel.toString();
                    console.log(selectedModel);


                    var  phoneService = [];
                $(".getPhoneService").each(function(){
                    if($(this).is(":checked")){
                        phoneService.push($(this).val());
                    }
                });

                var phoneService = phoneService.toString();
                        console.log(phoneService);
                $.ajax({
                    url: "<?php echo e(url('getBrandFilter')); ?>",
                    type:"get",
                    dataType:"html",
                    data:{phoneService:phoneService,selectedModel:selectedModel},

                    success:function(response){
                    console.log(response);
                    $('#filter').html(response);
                    //   $('#exampleModal'+id).modal('show');
                    },

                });

       }

      function wishlist(productID)
      {
        //   alert(colorID);
        <?php if(!Auth::user()): ?>
          window.location.href = "../signin";
        <?php else: ?>
        $.ajax({
            type:"get",
            url: "<?php echo e(url('add-wishlist')); ?>/"+productID,

            success:function(wishlist)
            {
               window.location.reload();
               alert('Successfully add into your wishlist !');

            },error:function(error){
               console.log(error);
            }

            });
        <?php endif; ?>

      }

    function undoWishlist(id)
    {
        <?php if(!Auth::user()): ?>
          window.location.href = "../signin";
        <?php else: ?>
        $.ajax({
            type:"get",
            url: "<?php echo e(url('undo-wishlist')); ?>/"+id,

            success:function(wishlist)
            {
               window.location.reload();
            //    alert('Successfully Re into your wishlist !');

            },error:function(error){
               console.log(error);
            }

            });
        <?php endif; ?>
    }


</script>

<script>
    $(function() {
        $('#slider-container').slider({
            range: true,
            min: 0,
            max: 1000,
            values: [5, 1000],
            slide: function(event, ui) {
                $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
                var mi = ui.values[ 0 ];
                var mx = ui.values[ 1 ];
                filterSystem(mi, mx);

            }
        });
      $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
      " - $" + $( "#slider-range" ).slider( "values", 1 ) );

  });

function filterSystem(minPrice, maxPrice) {
    console.log(minPrice, maxPrice);

            $.ajax({
                url: "<?php echo e(url('getBrandFilter')); ?>",
                type:"get",
                dataType:"html",
                data:{minPrice:minPrice,maxPrice:maxPrice},
                success:function(response){
                console.log(response);
                $('#filter').html(response);
                //   $('#exampleModal'+id).modal('show');
                },

            });

	$("#computers div.system").hide().filter(function() {

		var price = parseInt($(this).data("price"), 10);

        return price >= minPrice && price <= maxPrice;

	}).show();
}
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\cellCity\resources\views/frontend/buy-phone.blade.php ENDPATH**/ ?>