<?php $__env->startSection('title'); ?> Orders <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
    .loader {
      border: 16px solid #f3f3f3;
      border-radius: 50%;
      border-top: 16px solid #3498db;
      width: 100px;
      height: 100px;
      -webkit-animation: spin 2s linear infinite; /* Safari */
      animation: spin 2s linear infinite;
    }

    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes  spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }

    .code
    {
        margin-bottom:10px;
    }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Orders <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?> Repair <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?> Orders <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                            
                                            
                                            <div id="loader" class="loader justify-content-center" style="display: none; margin: auto;
                                            padding: 10px;">

                                            </div>
                                        </div>

                                        <div class="table-responsive">
                                            <table id="example3" class="table table-bordered table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>ID</th>
                                                        <th>Name</th>
                                                        <th>Created At</th>
                                                        <th>Shipping Address</th>
                                                        <th>Grand Price</th>
                                                        <th>Status</th>

                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__empty_1 = true; $__currentLoopData = $productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $orderSale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr>
                                                        
                                                        <td><?php echo e($orderSale->id); ?></td>
                                                        <?php if(isset($orderSale->user_id)): ?>
                                                        <td><?php echo e($orderSale->user->name ?? ''); ?></td>
                                                        <?php else: ?>
                                                        <td><?php echo e($orderSale->shipAddress->name); ?></td>
                                                        <?php endif; ?>

                                                        <td><?php echo e($orderSale->created_at->format('D-m-Y h:s')); ?></td>

                                                        <td><?php echo e($orderSale->shipAddress->shipaddress); ?></td>
                                                        <td>
                                                            $<?php echo e($orderSale->grand_total); ?>

                                                        </td>

                                                        <td>
                                                            <?php if($orderSale->status == 2): ?>
                                                            <span class="badge badge-success">complete</span>
                                                            <?php elseif($orderSale->status == 1): ?>
                                                            <span class="badge badge-warning">shipping</span>
                                                            <?php else: ?>
                                                            <span class="badge badge-secondary">Pending</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td style="display: flex">
                                                            <a href="#" onclick="orderViewDetails('<?php echo e($orderSale->id); ?>')" class="mr-3 text-success" title="view order"><i class="fa fa-eye font-size-18"></i></a>
                                                            <?php if($orderSale->status == 0): ?>
                                                            <a href="#" onclick="sendCode('<?php echo e($orderSale->id); ?>')" class="mr-3 text-warning" title="send Tracking Code" > <i class="fa fa-edit font-size-18"></i></a>
                                                            <?php endif; ?>
                                                            <a href="<?php echo e(route('admin.delete.productorder',$orderSale->id)); ?>" class="mr-3 text-danger" title="delete order"><i class="fa fa-trash font-size-18"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                        <tr>
                                                            <td colspan="5">
                                                              Soory No Order Yet...
                                                            </td>
                                                        </tr>
                                                    <?php endif; ?>


                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <!-- Modal -->


  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">

      <!-- Modal content-->
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title">Shipping Address </h4>
        </div>
        <div class="modal-body">
            <div id="showModels">

            </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
        </div>
      </div>

    </div>
  </div>

</div>



<div class="modal fade" id="empModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Sale Order </h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
      <div class="modal-body" id="saleOrder">

      </div>

      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


  
<div class="modal fade bd-example-modal-lg" id="codeModel" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Send Shipping tracking code </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                  <span aria-hidden="true">&times;</span>
                </button>
              </div>
          <div class="modal-body" >
            <form id="sendcode" method="POST">
                <?php echo csrf_field(); ?>
                <div class="code">
                   <input type="text" id="code" name="code" class="form-control" placeholder="Enter Code Here">
                   <input type="hidden" name="id" id="id" >
                   
                </div>
                <div class="text-center">
                   <button id="submit" class="btn btn-primary">Submit</button>
                </div>
            </form>
          </div>

          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">
$(document).ready(function() {
   $('#example3').DataTable({
        "order": [[ 0, "desc" ]]
    });

    });
    function viewDetail(id){
   $.ajax({
        url: "<?php echo e(url('admin/shippingAddress')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
          $('#myModal').modal('show');
        },

       });
    }

    function selectTech(event,id){

        $("#loader").show();
    var value=$(event).val()
     let _token   = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
        url: "<?php echo e(url('admin/assignTech')); ?>",
        type:"post",
        data:{
            orderId:id,
            techid:value,
            _token:_token
        },
        success:function(response){
        //   console.log(response);
        $("#loader").hide();
          window.location.reload();
        //   alert(response);
        //   $('#or'+id).empty();
        },

       });

    }


    function orderViewDetails(id)
    {
        $.ajax({
        url: "<?php echo e(url('admin/orderViewDetails')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#saleOrder').html(response);
          $('#empModal').modal('show');
        },

       });
    }

   function sendCode(id)
   {
       $('#codeModel').modal('show');
       $('#id').val(id);
   }
    $('#sendcode').on('submit',function(e){
        e.preventDefault();
        let name = $('#code').val();
        let id= $('#id').val();
        let _token = "<?php echo e(csrf_token()); ?>";
        // alert(name);
        $.ajax({
          url: "<?php echo e(url('admin/send-code')); ?>",
          type:"POST",
          data:{
            _token:_token,
            code:name,
            id:id,
          },
          success:function(response){
            console.log(response);
            alert('Successfully Send The Shipping Code from Desired User');
            window.location.reload();
          },
         });
        });

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/productOrder/list.blade.php ENDPATH**/ ?>