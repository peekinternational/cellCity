

<?php $__env->startSection('title'); ?> Orders <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>


<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Orders <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?> Repair <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?> Orders <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


                        <div class="row">
                            <?php if(Session::has('message')): ?>
                            <div class="col-12">
                                <?php echo Session::get('message'); ?>

                            </div>
                            <?php endif; ?>
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                            
                                            
                                        </div>

                                        <div class="table-responsive">
                                            <table class="table table-centered table-nowrap" id="example">
                                                <thead class="thead-light">
                                                    <tr>

                                                        <th>Order ID</th>
                                                        <th>Billing Name</th>
                                                        <th>Date & Time</th>
                                                        <th>Total</th>
                                                        <th>Status</th>
                                                        <th>Payment Method</th>
                                                         <th>Status</th>
                                                        <th>Technician</th>

                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $RepairOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><a href="javascript: void(0);" class="text-body font-weight-bold">#<?php echo e($order->id); ?></a> </td>
                                                        <td><?php echo e($order->name); ?></td>
                                                        <td>
                                                            <?php echo e($order->date); ?>, <?php echo e($order->time); ?>

                                                        </td>
                                                        <?php
                                                          $repairOrderType = App\Models\TemporaryOrderType::where('order_Id',$order->orderId)->get();
                                                            // dd($RepairOrders);
                                                        ?>
                                                        <td>
                                                           $<?php echo e($repairOrderType->sum('price')); ?>

                                                        </td>
                                                         <td>
                                                            <?php if($order->pay_status == 'paid'): ?>
                                                            <span class="badge badge-pill badge-soft-success font-size-12">Paid</span>
                                                            <?php else: ?>
                                                             <span class="badge badge-pill badge-soft-warning font-size-12">Unpaid</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td>
                                                            <!-- Button trigger modal -->
                                                           <span class="badge badge-pill badge-soft-success font-size-12"> <?php echo e($order->pay_method); ?></span>
                                                        </td>
                                                        <?php
                                                          $techId = App\Models\User::where('id',$order->techId)->first();
                                                        ?>
                                                       <td>
                                                        <?php if($order->order_status == 3 && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-warning">Assign</span>

                                                        <?php elseif($order->order_status == 1  && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-success">Accept</span>
                                                        <?php elseif($order->order_status == 0  && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-secondary">Pendding</span>
                                                        <?php elseif($order->order_status == 2  && $order->techId == null): ?>
                                                        <span class="badge badge-pill badge-danger">Reject</span>
                                                        <?php else: ?>
                                                        <span class="badge badge-pill badge-info">Not Assign</span>
                                                        <?php endif; ?>
                                                       </td>
                                                        <td id="or<?php echo e($order->id); ?>">
                                                          <?php if($order->techId === null || $order->techId === 0): ?>
                                                          <select onchange="selectTech(this,'<?php echo e($order->id); ?>')" class="form-control select2">
                                                            <option selected="">Select Technician</option>

                                                            <?php $__currentLoopData = CityClass::allTech(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tech->id); ?>"><?php echo e($tech->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                          
                                                            <?php else: ?>
                                                            <?php echo e($techId->name ?? 'Deleted Tech'); ?>


                                                           <?php endif; ?>

                                                        </td>
                                                        <td>
                                                            <a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal<?php echo e($order->id); ?>" onclick="viewDetail('<?php echo e($order->id); ?>')" class="mr-3 text-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="View Detail"><i class="mdi mdi-eye font-size-18"></i></a>
                                                            <a href="<?php echo e(url('admin/accept-orderUpdate',$order->id)); ?>" class="mr-3 text-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Accept "><i class="mdi mdi-check font-size-18"></i></a>
                                                            <a href="<?php echo e(url('admin/delete-orderUpdate',$order->id)); ?>" class="text-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Reject"><i class="mdi mdi-close font-size-18"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <!-- Modal -->
                <div id="showModels"></div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">

    function viewDetail(id){
   $.ajax({
        url: "<?php echo e(url('admin/checkRepairTypes')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
          $('#exampleModal'+id).modal('show');
        },

       });
    }

    function selectTech(event,id){

    var value=$(event).val()
     let _token   = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
        url: "<?php echo e(url('admin/assignTech')); ?>",
        type:"post",
        data:{
            orderId:id,
            techid:value,
            _token:_token
        },
        success:function(response){
        //   console.log(response);
          window.location.reload();
        //   alert(response);
        //   $('#or'+id).empty();
        },

       });

    }

    function rejectOrder(id)
    {
        $.ajax({
        url: "<?php echo e(url('admin/rejectOrder')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);

         location.reload();
        //   alert(response);
        },

       });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/checkupdate.blade.php ENDPATH**/ ?>