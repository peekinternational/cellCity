          <?php $__currentLoopData = $RepairTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <input type="hidden" name="model_Id" form="repairType" value="<?php echo e($type->model_Id); ?>">
          <div>
            <div class="fade-on-mount normal-elemnt-active">
              <div class="multiple-answer-component-wrapper">
                <label class="custom_check" onchange="custom_check('<?php echo e($type->id); ?>','<?php echo e($type->repair_type); ?>','<?php echo e($type->price); ?>')">
                  <div class="selection-inidicator">
                    <input type="checkbox" form="repairType" id="check<?php echo e($type->id); ?>" name="repair_type[]" value="<?php echo e($type->id); ?>">
                    <span class="checkmark"></span>
                  </div>
                  <div class="answer-content"><?php echo e($type->repair_type); ?><span class="price">+($<?php echo e($type->price); ?>)</span></div>
                </label>
              </div>
            </div>
          </div>

 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/repair-type.blade.php ENDPATH**/ ?>