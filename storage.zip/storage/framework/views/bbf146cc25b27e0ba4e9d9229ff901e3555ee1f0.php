<--========== Left Sidebar Start ========== -->
<?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin|blogs|zipcode')): ?>
<div class="vertical-menu">

    <div data-simplebar class="h-100">

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>
                <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')): ?>
                <li>
                    <a href="<?php echo e(url('admin')); ?>" class="waves-effect">
                        <i class="bx bx-home-circle"></i>
                        <span>Dashboards</span>
                    </a>

                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-detail"></i>
                        <span>Customers</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/addCustomer')); ?>">Add Customer</a></li>
                        <li><a href="<?php echo e(url('admin/customers')); ?>">Customers List</a></li>
                    </ul>
                </li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-detail"></i>
                        <span>Technicians</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/addTechnician')); ?>">Add Technician</a></li>
                        <li><a href="<?php echo e(url('admin/technicians')); ?>">Technicians List</a></li>
                    </ul>
                </li>


                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span>Repair</span>
                    </a>
                    <?php
                        $repair = App\Models\RepairOrder::where('notification',0)->get();
                        $repairModify = App\Models\Temporary::where('notification',0)->get();
                    ?>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/repair-steps')); ?>">Create Repair Order</a></li>
                        <li><a href="<?php echo e(url('admin/repairOrders')); ?>">Orders List
                             <?php if($repair->count() > 0): ?>
                             <span class="badge badge-pill badge-success"><?php echo e($repair->count()); ?></span>
                             <?php else: ?>

                            <?php endif; ?> </a></li>
                        <li><a href="<?php echo e(url('admin/checkUpdateOrders')); ?>">Check Update Orders
                            <?php if($repairModify->count() > 0): ?>
                            <span class="badge badge-pill badge-success"><?php echo e($repairModify->count()); ?></span>
                            <?php else: ?>

                           <?php endif; ?>
                         </a></li>
                        <li><a href="<?php echo e(url('admin/completed-orders')); ?>">Completed Repair Orders</a></li>
                        <li><a href="<?php echo e(url('admin/brands/create')); ?>">Add Brand</a></li>
                        <li><a href="<?php echo e(url('admin/brands')); ?>">Brands List</a></li>
                        <li><a href="<?php echo e(url('admin/models/create')); ?>">Add Model</a></li>
                        <li><a href="<?php echo e(url('admin/models')); ?>">Model List</a></li>
                        <li><a href="<?php echo e(url('admin/repairTypes/create')); ?>">Add Repair Types</a></li>
                        <li><a href="<?php echo e(url('admin/repairTypes')); ?>">Repair Types List</a></li>


                    </ul>
                </li>


                <?php
                    $orderSale = App\Models\OrderSale::where('notification',0)->get();
                    // $repairModify = App\Models\Temporary::where('notification',0)->get();
                ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span>Products</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/product/create')); ?>">Add Product</a></li>
                        <li><a href="<?php echo e(url('admin/product')); ?>">Products List</a></li>

                        <li><a href="<?php echo e(url('admin/productOrder')); ?>">Orders

                            <?php if($orderSale->count() > 0): ?>
                            <span class="badge badge-pill badge-success"><?php echo e($orderSale->count()); ?></span>
                            <?php else: ?>

                           <?php endif; ?>
                        </a></li>
                        

                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span>Accessories</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/accessory/create')); ?>">Add Accessories</a></li>
                        <li><a href="<?php echo e(url('admin/accessory')); ?>">Accessories List</a></li>

                        <li><a href="<?php echo e(route('admin.category.create')); ?>">Add Category</a></li>
                        <li><a href="<?php echo e(route('admin.category.index')); ?>">Category List</a></li>
                        

                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span>Coupon</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('admin.coupon.create')); ?>">Add Coupon</a></li>
                        <li><a href="<?php echo e(route('admin.coupon.index')); ?>">Coupon List</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span>Phone Service</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('admin.service.create')); ?>">Add Phone Service</a></li>
                        <li><a href="<?php echo e(route('admin.service.index')); ?>">Phone Service List</a></li>
                    </ul>
                </li>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bx-store"></i>
                        <span>FAQs Management</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(route('admin.faqs.index')); ?>">FAQs List</a></li>
                        <li><a href="<?php echo e(route('admin.faqs.create')); ?>">Add FAQs</a></li>

                    </ul>
                </li>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin|zipcode')): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-detail"></i>
                        <span>Zip Code Manage</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/zipCode/create')); ?>">Add Zip Code</a></li>
                        <li><a href="<?php echo e(url('admin/zipCode')); ?>">Zip Code List</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin|blogs')): ?>
                <li>
                    <a href="javascript:void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-detail"></i>
                        <span>Blog Management</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/blog/create')); ?>">Add Blog</a></li>
                        <li><a href="<?php echo e(url('admin/blog')); ?>">Blog List</a></li>
                    </ul>
                </li>
                <?php endif; ?>
                <?php if(auth()->check() && auth()->user()->hasRole('SuperAdmin')): ?>
                <li>
                    <a href="javascript: void(0);" class="has-arrow waves-effect">
                        <i class="bx bxs-user-detail"></i>
                        <span>Admin Role</span>
                    </a>
                    <ul class="sub-menu" aria-expanded="false">
                        <li><a href="<?php echo e(url('admin/role/create')); ?>">Add Role</a></li>
                        <li><a href="<?php echo e(url('admin/role/list')); ?>">Role List</a></li>
                    </ul>
                </li>
                <?php endif; ?>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<?php endif; ?>
<!-- Left Sidebar End
<?php /**PATH C:\xampp\htdocs\cellCity\cellCity\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>