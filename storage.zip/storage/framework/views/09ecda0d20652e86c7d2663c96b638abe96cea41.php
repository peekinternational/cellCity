

<?php $__env->startSection('title'); ?> Customer Add <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Customer Add  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?><?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <div class="row">
                              <?php if(Session::has('message')): ?>
                              <div class="col-12">
                                  <?php echo Session::get('message'); ?>

                              </div>
                              <?php endif; ?>
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.category.store')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>



                                            <div class="form-group row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Category</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" name="category" type="text" placeholder="Enter category"  value="<?php echo e($category->category); ?>"  id="example-text-input">
                                                    <span class="text-danger"><?php echo e($errors->first('category')); ?></span>
                                                </div>
                                            </div>



                                        <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                    </div>

                                   </form>

                                    </div>
                                </div>
                            </div> <!-- end col -->

                        </div>
                        <!-- end row -->

                        <!-- end row -->
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/accessoryCategory/edit.blade.php ENDPATH**/ ?>