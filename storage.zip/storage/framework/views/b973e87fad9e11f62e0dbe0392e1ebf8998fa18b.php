

<?php $__env->startSection('title'); ?> Modify Repair Order <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
        <?php $__env->slot('title'); ?> Modify Repair Order <?php $__env->endSlot(); ?>
        <?php $__env->slot('li_1'); ?> <?php $__env->endSlot(); ?>
        <?php $__env->slot('li_2'); ?><?php $__env->endSlot(); ?>
    <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-8">
                <div class="card">
                    <?php if(Session::has('message')): ?>
                        <div class="form-group row">
                            <div class="col-md-10">
                                <label for="example-text-input" class="col-md-2 col-form-label" center></label>

                                <?php echo Session::get('message'); ?>

                            </div>
                        </div>
                    <?php endif; ?>
                    <div class="card-body">

                        <form action="<?php echo e(url('admin/repairModel-update', $repairOrders->id)); ?>" method="post">
                            <?php echo e(csrf_field()); ?>


                            <?php if($repairOrders->order_create == 'admin'): ?>
                                <div class="form-group row">
                                    <label for="example-text-input" class="col-md-2 col-form-label">Customer</label>
                                    <div class="col-md-10">
                                        <select class="form-control selectpic" name="userId" required="">
                                            <option selected="">Select Customer</option>
                                            <?php $__currentLoopData = CityClass::allUser(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>"
                                                    <?php echo e($user->id == $repairOrders->userId ? 'selected' : ''); ?>>
                                                    <?php echo e($user->name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>

                                    </div>
                                </div>
                            <?php else: ?>
                                <input type="hidden" name="userId" value="<?php echo e($repairOrders->userId); ?>">

                            <?php endif; ?>

                            <div class="form-group row">
                                <label for="example-text-input" class="col-md-2 col-form-label">Zip Code</label>
                                <div class="col-md-10">
                                    <select class="form-control selectpic" name="zip_code" required="">
                                        <option selected="">Select Zip Code</option>
                                        <?php $__currentLoopData = CityClass::ZipCode(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $zip): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($zip->id); ?>"
                                                <?php echo e($zip->name == $zip->zipcode ? 'selected' : ''); ?>><?php echo e($zip->zipcode); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-md-2 col-form-label">Brands</label>
                                <div class="col-md-10">
                                    <select class="form-control selectpic" name="brand" id="brand"
                                        onchange="getModel(this)">
                                        <option selected="">Select Brand</option>
                                        <?php $__currentLoopData = CityClass::brands(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($brand->id); ?>,<?php echo e($brand->brand_name); ?>"
                                                <?php echo e($brand->id == $repairOrders->pModel->brand_Id ? 'selected' : ''); ?>>
                                                <?php echo e($brand->brand_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>

                                </div>
                            </div>

                            <div class="form-group row" id="showModels">
                                <label for="example-text-input" class="col-md-2 col-form-label">Models</label>
                                <div class="col-md-10">
                                    <select class="form-control selectpic" name="model_Id" id="model_Id" required=""
                                        onchange="getRepair(this)">

                                        <option value="<?php echo e($model->id); ?>"><?php echo e($model->model_name); ?></option>

                                    </select>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="example-text-input" class="col-md-2 col-form-label">Repair Type</label>
                                <div class="col-md-10" id="model-repair">

                                    <?php $__empty_1 = true; $__currentLoopData = $checkbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                                        <div class="form-check">
                                            <input class="form-check-input" name="repair_type[]" type="checkbox"
                                                value="<?php echo e($repair->repair_type); ?>" id="<?php echo e($repair->id); ?>"
                                                <?php echo e($repairOrders->id == $repair->order_Id ? ' checked' : ''); ?>>
                                            <label class="form-check-label" for="<?php echo e($repair->id); ?>">
                                                <?php echo e($repair->repair_type); ?> <?php echo e($repair->price); ?>

                                            </label>

                                        </div>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <span>Oops No Repair Product Available !</span>
                                    <?php endif; ?>

                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="example-text-input" class="col-md-2 col-form-label">Date</label>
                                <div class="col-md-10">
                                    <input class="form-control" name="date" type="date" placeholder="Select date"
                                        title="Select Date" value="<?php echo e($repairOrders->date); ?>" id="txtDate">
                                    <span class="text-danger"><?php echo e($errors->first('date')); ?></span>
                                </div>
                            </div>
                            <div class="form-group row">
                                <label for="example-text-input" class="col-md-2 col-form-label">Time</label>
                                <div class="col-md-10">
                                    <input class="form-control" name="time" type="time" placeholder="Select time"
                                        title="Select Date" value="<?php echo e($repairOrders->time); ?>" id="example-text-input"
                                        required>
                                    <span class="text-danger"><?php echo e($errors->first('price')); ?></span>
                                </div>
                            </div>
                            <input type="hidden" name="check" value="" id="checkId">
                            <div class="form-group row">
                                <label for="example-text-input" class="col-md-2 col-form-label">Instruction</label>
                                <div class="col-md-10">
                                    <textarea class="form-control" name="instruction" type="text"
                                        placeholder="Select instruction" title="Select instruction" <?php if(old('instruction')): ?> value="<?php echo e($repairOrders->instructions); ?>" <?php endif; ?>
                                        id="example-text-input" required><?php echo e($repairOrders->instructions); ?></textarea>
                                    <span class="text-danger"><?php echo e($errors->first('instruction')); ?></span>
                                </div>
                            </div>

                            <div class="text-center mt-4">
                                <button type="submit" class="btn btn-primary waves-effect waves-light">Update</button>
                            </div>

                        </form>

                    </div>
                </div>
            </div> <!-- end col -->



            
            <div class="col-md-4">
                <div class="card">
                    <div class="card-body">
                        <div class="my-cart-desktop" id="priceCart">
                            <!-- <div class="my-cart-wrapper-not-fixed "></div> -->
                            <div class="my-cart-wrapper ">
                                <div class="my-cart-content-wrapper">
                                    <div class="my-cart-device-section-wrapper">
                                        <div class="my-cart-device-section-header">
                                            <div class="my-cart-device-section-header-image-title">
                                                <div id="brandname">
                                                    <h5>Brand Name:<b style="float: center">
                                                            <?php echo e($model->brand->brand_name); ?></b>
                                                        <h5>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="services-aggregation-details-wrapper">

                                            <div id="PmodelName">
                                                <h6>Model Name: <b><?php echo e($model->model_name); ?></b> </h6>
                                            </div>
                                            <?php
                                                $total = 0;
                                            ?>
                                            <div class="services-aggregation-details" id="priceDetails">
                                                <?php $__currentLoopData = $checkbox; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <div class="aggregate-service">
                                                        <span class="service-name">Repair Type:
                                                            <?php echo e($item->repair_type); ?></span>
                                                        <span class="service-price"><b>$<?php echo e($item->price); ?></b></span>
                                                    </div>

                                                    <?php

                                                        $total = $total + $item->price;
                                                    ?>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>

                                        </div>
                                        <hr>
                                        <div class="subtotal-container" id="totalCost">
                                            <span>Estimated :</span><span class="my-cart-small-text-bold"><b>
                                                    $<?php echo e($total); ?></b></span>
                                        </div>
                                        <div class="disclaimer-container"></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- end row -->

    <!-- end row -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

    <script type="text/javascript">
        $(function() {
            $('.selectpic').select2();
        });

        function getModel(event) {
            $("#PmodelName").empty();
            $("#totalCost").empty();
            $("#priceDetails").empty();
            $("#checkId").val('check');
            // alert($(event).val());
            var brand = $(event).val().split(',');
            var id = brand[0];
            var brandName = brand[1];


            $('#brandname').html('<h5>Brand Name :<b>' + brandName + '</b></h5>');
            $('#model-repair').hide();
            //    var id =$(event).val();
            $.ajax({
                url: "<?php echo e(url('admin/getModels')); ?>/" + id,
                type: "get",
                success: function(response) {
                    console.log(response);
                    $('#showModels').html(response);
                    $('#exampleModal' + id).modal('show');
                },

            });

        }

        function getRepair(event) {

            $("#PmodelName").empty();
            $("#totalCost").empty();
            $("#priceDetails").empty();

            var model = $(event).val().split(',');
            // alert(model);
            var id = model[0];
            var modelName = model[1];
            $('#PmodelName').html('<h6>Model Name :<b>' + modelName + '</b></h6>');

            $('#model-repair').show();
            var id = $(event).val();
            $.ajax({
                url: "<?php echo e(url('admin/getRepair')); ?>/" + id,
                type: "get",
                success: function(response) {
                    console.log(response);



                    $('#model-repair').html(response);
                    $('#exampleModal' + id).modal('show');
                },

            });

        }



        $(function() {
            var dtToday = new Date();

            var month = dtToday.getMonth() + 1;
            var day = dtToday.getDate();
            var year = dtToday.getFullYear();
            if (month < 10)
                month = '0' + month.toString();
            if (day < 10)
                day = '0' + day.toString();

            var maxDate = year + '-' + month + '-' + day;

            // or instead:
            // var maxDate = dtToday.toISOString().substr(0, 10);
            // alert(maxDate);
            $('#txtDate').attr('min', maxDate);
        });


        /// Cart



        var total = 0;

        function custom_check(id, repair_type, price) {

            if ($('#check' + id).is(":checked")) {
                // consol("Checkbox is checked.");
                //  $('#continue_btn').show();
                var html = '<div class="aggregate-service" id="' + id + '">' +
                    '<span class="service-name">' + repair_type + ' </span>' +
                    '<span class="service-price"><b>$' + price + '</b></span>' +
                    '</div>';
                $('#priceDetails').append(html);
                total = total + parseInt(price);
                console.log(total);
                $('#totalCost').show();
                $('#totalCost').html('<span>Estimated</span><span class="my-cart-small-text-bold"> $' + total + '</span>');
            } else {
                console.log('uncheck');
                // $('#continue_btn').hide();
                console.log($('#check' + id).val());
                total = total - parseInt(price);
                $('#totalCost').html('<span>Estimated</span><span class="my-cart-small-text-bold"> $' + total + '</span>');
                $('#' + id).remove();

            }

            // alert(price);

        }
    </script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/modify-order.blade.php ENDPATH**/ ?>