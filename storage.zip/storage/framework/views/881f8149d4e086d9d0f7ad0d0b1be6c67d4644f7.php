
<label for="example-text-input" class="col-md-2 col-form-label">Models</label>
<div class="col-md-10">
<select class="form-control selectpic" name="model_id" required="" >
    <option value="null" selected="">Select Model</option>
    <?php $__currentLoopData = $pmodels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
     <option value="<?php echo e($model->id); ?>"><?php echo e($model->model_name); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</select>
</div>


<script>
       $(function() {
  $('.selectpic').select2();
});

</script>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/products/getModel.blade.php ENDPATH**/ ?>