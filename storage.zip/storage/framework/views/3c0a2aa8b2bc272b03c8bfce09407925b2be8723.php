

<?php $__env->startSection('title'); ?> Product List <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Product List  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?> Product <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?> Product List <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
   <?php $__env->startSection('css'); ?>

   <?php $__env->stopSection(); ?>

                        <div class="row">
                             <?php if(Session::has('message')): ?>
                              <div class="col-12">
                                  <?php echo Session::get('message'); ?>

                              </div>
                              <?php endif; ?>
                            <div class="col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="table-responsive">
                                            <table class="table table-centered table-nowrap table-hover" id="example" cellspacing="0" width="100%" >
                                                <thead class="thead-light">
                                                    <tr>
                                                        <th scope="col">#</th>

                                                        <th scope="col">Brand Name</th>
                                                        <th scope="col">Model Name</th>
                                                        <th scope="col">Category</th>
                                                        <th scope="col">Name</th>
                                                        <th scope="col">Sell Price</th>
                                                        <th scope="col">Original Price</th>
                                                        <th scope="col">Quantity</th>

                                                        <th scope="col">Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($index + 1); ?> </td>

                                                        <?php
                                                            $model = App\Models\Pmodel::whereId($accessory->model_id)->first();
                                                            ?>
                                                        <td>
                                                           <?php echo e($model->brand->brand_name); ?>


                                                        </td>

                                                        <td>
                                                            <?php echo e($model->model_name); ?>


                                                        </td>
                                                       <td><?php echo e($accessory->category); ?></td>
                                                       <td><?php echo e($accessory->name); ?></td>
                                                       <td><?php echo e($accessory->sell_price); ?></td>
                                                       <td><?php echo e($accessory->orig_price); ?></td>
                                                       <td><?php echo e($accessory->quantity); ?></td>




                                                        <td>
                                                            <ul class="list-inline font-size-20 contact-links mb-0">
                                                                <li class="list-inline-item px-2">
                                                                    <a href="#" onclick="viewAccessory('<?php echo e($accessory->id); ?>')" class="mr-3 text-success" title="view order"><i class="fa fa-eye font-size-18"></i></a>
                                                                </li>
                                                                <li class="list-inline-item px-2">
                                                                    <a href="<?php echo e(url('admin/accessory/'.$accessory->id.'/edit')); ?>" data-toggle="tooltip" data-placement="top" title="Edit"><i class="mdi mdi-account-edit-outline"></i></a>
                                                                </li>
                                                                <li class="list-inline-item px-2">
                                                                   <form action="<?php echo e(url('admin/product/'.$accessory->id)); ?>" method="post">
                                                                    <?php echo e(csrf_field()); ?>

                                                                       <?php echo method_field('DELETE'); ?>

                                                                       <label for="delZip" data-toggle="tooltip" data-placement="top" title="Delete" style="cursor: pointer;"><i class="mdi mdi-delete-circle-outline"></i></label>
                                                                       <input id="delZip" type="submit" name="" style="display: none">
                                                                   </form>

                                                                </li>
                                                              <!--   <li class="list-inline-item px-2">
                                                                    <a href="" data-toggle="tooltip" data-placement="top" title="Profile"><i class="mdi mdi-account-circle-outline"></i></a>
                                                                </li> -->
                                                            </ul>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                            </table>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="modal fade" id="empModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">

                            <div class="modal-dialog modal-lg" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Sale Order </h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                      <span aria-hidden="true">&times;</span>
                                    </button>
                                  </div>
                              <div class="modal-body" id="viewAccessory">
                                ...
                              </div>

                              <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                              </div>
                            </div>
                          </div>
                        </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    function viewAccessory(id)
    {
        // alert(id);

        $.ajax({
        url: "<?php echo e(url('admin/viewAccessory')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#viewAccessory').html(response);
          $('#empModal').modal('show');
        },

       });

    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\cellCity\resources\views/admin/accessories/index.blade.php ENDPATH**/ ?>