<footer class="footer">
    <div class="container-fluid">
        <div class="row">
            
        </div>
    </div>
</footer><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>