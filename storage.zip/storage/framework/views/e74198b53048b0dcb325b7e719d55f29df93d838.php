
<?php $__env->startSection('content'); ?>
  <div class="wrapper">
    <div class="main-panel">
      <!-- Navbar -->
      <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
        <div class="container-fluid">
          <div class="navbar-wrapper">
            <div class="navbar-toggle">
              <button type="button" class="navbar-toggler">
                <span class="navbar-toggler-bar bar1"></span>
                <span class="navbar-toggler-bar bar2"></span>
                <span class="navbar-toggler-bar bar3"></span>
              </button>
            </div>
            <a class="navbar-brand" href="#pablo">Orders Management</a>
          </div>
          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navigation" aria-controls="navigation-index" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
            <span class="navbar-toggler-bar navbar-kebab"></span>
          </button>
            <div class="collapse navbar-collapse justify-content-end" id="navigation">

            <ul class="navbar-nav">

              <li class="nav-item btn-rotate dropdown">
                <a class="nav-link dropdown-toggle" href="http://example.com" id="navbarDropdownMenuLink" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                  <p>
                    <span class="d-lg-none d-md-block">Some Actions</span>
                  </p>
                </a>
                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdownMenuLink">
                  <a class="dropdown-item" href="<?php echo e(url('technician/logout')); ?>">Logout</a>
                </div>
              </li>

            </ul>
          </div>
        </div>
      </nav>
      <!-- End Navbar -->
      <!-- <div class="panel-header panel-header-sm">


</div> -->
      <div class="content">
        <div class="row">
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Orders List</h4>
              </div>

              <div class="card-body">
                <div class="table-responsive">
                    <table id="example" class="table" >
                    <thead class=" text-primary">
                      <th colspan="2">Order ID#</th>
                      <th colspan="3">Modal</th>
                      <th colspan="2">Repair Type</th>
                      <th colspan="2">Price</th>
                      <th colspan="3">Payment Method</th>
                      <th colspan="3">Order Time</th>
                      <th>Status</th>
                      <th>Action</th>

                    </thead>
                    <tbody>
                     <?php
                       
                        $repairorders = App\Models\RepairOrder::where('techId',Auth::guard('tech')->user()->id)
                                                ->where('order_status','!=','4')
                                                ->get();
                        // dd($repairorders);
                     ?>
                      <?php $__currentLoopData = $repairorders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td colspan="2">#<?php echo e($order->id); ?></td>
                        <td colspan="2"><?php echo e(CityClass::modelName($order->model_Id)); ?></td>
                        <td colspan="3">
                          <?php $__currentLoopData = $order->repairorderstypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $repair): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php echo e($repair->repair_type); ?><br>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </td>
                         <td colspan="2">
                            $<?php echo e($order->repairorderstypes->sum('price')); ?>

                         </td>
                        <td colspan="3">
                            <!-- Button trigger modal -->
                           <span class="badge badge-pill badge-success font-size-12"> <?php echo e($order->pay_method); ?></span>
                        </td>
                        <td colspan="3"><?php echo e($order->date); ?> <?php echo e($order->time); ?></td>
                        <td>
                            <?php if($order->order_status == 3): ?>

                            <a href="#" onclick="acceptOrder('<?php echo e($order->id); ?>')" title="Accept"> <i class="fa fa-check text-primary"></i> </a>
                            <a href="#"  onclick="penddingOrder('<?php echo e($order->id); ?>')" title="Pendding"> <i class="fa fa-clock-o text-info"></i></a>
                            <a href="#" onclick="rejectOrder('<?php echo e($order->id); ?>')" title="Reject"> <i class="fa fa-times text-danger"></i></a>

                            <?php elseif($order->order_status == 1 && $order->techId !== null): ?>
                            <span class="badge badge-pill badge-primary">Accept</span>
                            <?php elseif($order->order_status == 0): ?>
                            <span class="badge badge-pill badge-secondary">Pendding</span>
                            <a href="#" onclick="acceptOrder('<?php echo e($order->id); ?>')" title="Accept"> <i class="fa fa-check text-primary"></i> </a>
                            <a href="#" onclick="rejectOrder('<?php echo e($order->id); ?>')" title="Reject"> <i class="fa fa-times text-danger"></i></a>
                            <?php elseif($order->order_status == 4 && $order->techId !== null): ?>
                            <span class="badge badge-pill badge-success">Completed</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if($order->order_status == 4 && $order->techId !== null): ?>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal<?php echo e($order->id); ?>" onclick="viewModal('<?php echo e($order->id); ?>')" class="mr-3 text-success" data-toggle="tooltip" data-placement="top" title="View Detail" data-original-title="View Detail"> <i class="fa fa-eye text-success"></i></a>
                            <?php elseif($order->order_status == 1 && $order->techId !== null): ?>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal<?php echo e($order->id); ?>" onclick="viewModal('<?php echo e($order->id); ?>')" class="mr-3 text-success" data-toggle="tooltip" data-placement="top" title="View Detail" data-original-title="View Detail"> <i class="fa fa-eye text-success"></i></a>
                            <a href="<?php echo e(url('tech/order-modify',$order->id)); ?>" title="Edit Order" > <i class="fa fa-pencil text-warning"></i></a>
                            <a href="<?php echo e(route('complete.order',$order->id.'?type=tech')); ?>" class="btn btn-primary btn-sm" title="pay the Order"><i class="fa fa-cash">Pay</i></a>
                            <?php else: ?>
                            <a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal<?php echo e($order->id); ?>" onclick="viewModal('<?php echo e($order->id); ?>')" class="mr-3 text-success" data-toggle="tooltip" data-placement="top" title="View Detail" data-original-title="View Detail"> <i class="fa fa-eye text-success"></i></a>
                            <a href="<?php echo e(url('tech/order-modify',$order->id)); ?>" title="Edit Order" > <i class="fa fa-pencil text-warning"></i></a>

                            <?php endif; ?>



                        </td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>

<div id="showModels"></div>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('script'); ?>
<script>
    function acceptOrder(id)
    {
        $.ajax({
        url: "<?php echo e(url('tech/acceptOrder')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
        //  alert(response);
         location.reload();
        },

       });
    }
    function viewModal(id)
    {
        $.ajax({
        url: "<?php echo e(url('tech/orderView')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
          $('#exampleModal'+id).modal('show');
        },

       });
    }

    function penddingOrder(id)
    {
        // alert(id);
        $.ajax({
        url: "<?php echo e(url('tech/penddingOrder')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);

          location.reload();
          // alert(response);
        },

       });
    }

    function rejectOrder(id)
    {
        $.ajax({
        url: "<?php echo e(url('tech/rejectOrder')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);

          location.reload();
          // alert(response);
        },

       });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.technician.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/technician/orders.blade.php ENDPATH**/ ?>