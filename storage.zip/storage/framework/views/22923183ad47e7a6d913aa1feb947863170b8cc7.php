<?php $__env->startSection('title'); ?> Coupon Add <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Coupon Add  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?><?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <div class="row">
                              <?php if(Session::has('message')): ?>
                              <div class="col-12">
                                  <?php echo Session::get('message'); ?>

                              </div>
                              <?php endif; ?>
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.coupon.store')); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>



                                            <div class="form-group row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Coupon Name</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" name="name" type="text" placeholder="Enter name" <?php if(old('name')): ?> value="<?php echo e(old('name')); ?>" <?php endif; ?>  name="name" id="example-text-input">
                                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label">Coupon Code</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" placeholder="Enter Coupon Code" <?php if(old('code')): ?> value="<?php echo e(old('code')); ?>" <?php endif; ?> name="code" id="example-search-input">
                                                    <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label"> Coupon Type</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" placeholder="Enter type" <?php if(old('type')): ?> value="<?php echo e(old('type')); ?>" <?php endif; ?> name="type" id="example-search-input">
                                                    <span class="text-danger"><?php echo e($errors->first('orig_price')); ?></span>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label"> value</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" placeholder="Enter Discount value like (-50%)" <?php if(old('value')): ?> value="<?php echo e(old('value')); ?>" <?php endif; ?> name="value" id="example-search-input">
                                                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                                                </div>
                                            </div>
                                             <div class="form-group row">
                                                <label for="example-tel-input" class="col-md-2 col-form-label">Description</label>
                                                <div class="col-md-10">
                                                    <textarea type="text" name="description" class="form-control" cols="30" rows="10"></textarea>
                                                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                                </div>
                                            </div>


                                        <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                    </div>

                                   </form>

                                    </div>
                                </div>
                            </div> <!-- end col -->

                        </div>
                        <!-- end row -->

                        <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(function() {
$('.selectpic').select2();
});

</script>

<script>
    function getModel(event)
    {
        var id = $(event).val();
        $.ajax({
        url: "<?php echo e(url('admin/accessory/getModels')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
        },

       });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/coupon/create.blade.php ENDPATH**/ ?>