<div class="table-responsive">
    <h2> Product </h2>
    <table class="table table-centered table-nowrap">
        <thead>
            <tr>
            <th>Brand Name</th>
            <th>Color</th>
            <th>Condition</th>
            <th>Storage</th>
            <th>Quantity</th>
            <th>payment_method</th>
            <th >Price</th>
            <th> Grand Price</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $productOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>

                <td><?php echo e($order->brand_name); ?>  <?php echo e($order->model_name); ?> </td>
                <td><?php echo e($order->color); ?></td>
                <td><?php echo e($order->condition); ?>  </td>
                <td><?php echo e($order->storage); ?></td>
                <td><?php echo e($order->quantity); ?></td>
                <td><span class="badge badge-pill badge-success"><?php echo e($order->payment_method); ?></span></td>
                <td><?php echo e($order->price); ?></td>
                <td><?php echo e($order->grand_price); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="6" class="text-center"> Nothing</td>
             </tr>
         <?php endif; ?>
        </tbody>
    </table>

    <h2> Accessory </h2>
    <table class="table table-centered table-nowrap">
        <thead>
            <tr>
            <th>Brand Name</th>
            <th>Category</th>
            <th>Name</th>

            <th>Quantity</th>
            <th>Payment Method</th>
            <th >Price</th>
            <th> Grand Price</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $accessoryOrder; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>

                <td><?php echo e($order->brand_name); ?>  <?php echo e($order->model_name); ?> </td>
                <td><?php echo e($order->access_category); ?></td>
                <td><?php echo e($order->access_name); ?>  </td>
                <td><?php echo e($order->quantity); ?></td>
                <td><span class="badge badge-pill badge-success"><?php echo e($order->payment_method); ?></span></td>
                <td><?php echo e($order->price); ?></td>
                <td><?php echo e($order->grand_price); ?></td>

            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
               <td colspan="6" class="text-center"> Nothing</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/productOrder/order_modal.blade.php ENDPATH**/ ?>