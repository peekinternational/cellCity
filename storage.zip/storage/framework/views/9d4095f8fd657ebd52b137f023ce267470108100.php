<link rel="stylesheet" type="text/css" href="<?php echo e(asset('frontend-assets/css/custom.css')); ?>">
<?php $__env->startSection('content'); ?>
<!--Page Title-->
<!-- <section class="page-title" style="background-image: url(frontend-assets/images/background/3.jpg);">
	<div class="auto-container">
    	<ul class="bread-crumb">
            <li><a href="index-2.html">Home</a></li>
            <li class="active">Shop</li>
        </ul>
    	<h1>Shop</h1>
    </div>
</section> -->
<!--End Page Title-->

<!--Shop Section-->
<section class="shop-section shop-page">
	<div class="auto-container">
    	<!--Sort By-->
      <h3 class="_3n9_eRVa OCgW6kA95RgHDgyrkt-3F">Buy Accessories</h3>

        <form name="contactUsForm" id="contactUsForm" method="post" action="javascript:void(0)">
            <?php echo csrf_field(); ?>
      <div data-test="carrier-filters" class="_37xvF8QgM_NvGXx3HcYuJ2">
        <div class="a-cell row" data-v-2b8789a2="">

          <div class="a-cell xs-12 md-3" data-v-2b8789a2="">
            <div class="axop9d4ghf_ZiU7FQc-M8 baseselect-wrapper _2u25sfWmf6NUCbJ_StTs_r" data-v-2b8789a2=""><!---->
                <select id="simlock" onchange="getBrand(this)" name="brand_id" class="_3Iq8JGYZpyTj97wvi5Wyu7 eUlOsp7XbB9G1L8SEMMpU baseselect-field">
                    <option selected>Select Brand....</option>
                    <?php $__currentLoopData = CityClass::brands(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($brand->id); ?>"><?php echo e($brand->brand_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>

              <label data-test="baseselect-label" class="PSXfa64BhcchUXTYm8jxr _2Y-fYnDKPqxkYV__KtgvWD baseselect-label">
                
              </label>
              <div class="_3CTJYWu3hsWyWna_ZcsF5I">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 443.9 476.5" data-test="baseselect-icon" class="-S5BM_soVHE3yxeKelL2Q _1-GUUYIHoGjHHKudYw6-sr"><path d="M220.2 355.7c-3.1 0-6.1-1.2-8.5-3.5L9.1 149.6c-4.7-4.7-4.7-12.3 0-17 4.7-4.7 12.3-4.7 17 0l194.1 194.1 197-197c4.7-4.7 12.3-4.7 17 0 4.7 4.7 4.7 12.3 0 17L228.7 352.2c-2.4 2.3-5.4 3.5-8.5 3.5z"></path></svg>
              </div>
            </div>
          </div>
          <div class="a-cell xs-12 md-3" data-v-2b8789a2="">
            <div id="showModel" class="axop9d4ghf_ZiU7FQc-M8 baseselect-wrapper _2u25sfWmf6NUCbJ_StTs_r" data-v-2b8789a2="" ><!---->
                <select id="simlock" onchange="getModel(this)" name="model_id" class="_3Iq8JGYZpyTj97wvi5Wyu7 eUlOsp7XbB9G1L8SEMMpU baseselect-field">
                    <option selected>Select Model ....</option>

                  </select>

              <label data-test="baseselect-label" class="PSXfa64BhcchUXTYm8jxr _2Y-fYnDKPqxkYV__KtgvWD baseselect-label">
                
              </label>
              <div class="_3CTJYWu3hsWyWna_ZcsF5I">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 443.9 476.5" data-test="baseselect-icon" class="-S5BM_soVHE3yxeKelL2Q _1-GUUYIHoGjHHKudYw6-sr"><path d="M220.2 355.7c-3.1 0-6.1-1.2-8.5-3.5L9.1 149.6c-4.7-4.7-4.7-12.3 0-17 4.7-4.7 12.3-4.7 17 0l194.1 194.1 197-197c4.7-4.7 12.3-4.7 17 0 4.7 4.7 4.7 12.3 0 17L228.7 352.2c-2.4 2.3-5.4 3.5-8.5 3.5z"></path></svg>
              </div>
            </div>
          </div>
          <div class="a-cell xs-12 md-3" data-v-2b8789a2="">
            <div id="showCategory" class="axop9d4ghf_ZiU7FQc-M8 baseselect-wrapper _2u25sfWmf6NUCbJ_StTs_r" data-v-2b8789a2=""><!---->
                <select id="simlock" name="category_id" class="_3Iq8JGYZpyTj97wvi5Wyu7 eUlOsp7XbB9G1L8SEMMpU baseselect-field">
                    <option selected>Select Category ....</option>

                  </select>

              <label data-test="baseselect-label" class="PSXfa64BhcchUXTYm8jxr _2Y-fYnDKPqxkYV__KtgvWD baseselect-label">
                
              </label>
              <div class="_3CTJYWu3hsWyWna_ZcsF5I">
                <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 443.9 476.5" data-test="baseselect-icon" class="-S5BM_soVHE3yxeKelL2Q _1-GUUYIHoGjHHKudYw6-sr"><path d="M220.2 355.7c-3.1 0-6.1-1.2-8.5-3.5L9.1 149.6c-4.7-4.7-4.7-12.3 0-17 4.7-4.7 12.3-4.7 17 0l194.1 194.1 197-197c4.7-4.7 12.3-4.7 17 0 4.7 4.7 4.7 12.3 0 17L228.7 352.2c-2.4 2.3-5.4 3.5-8.5 3.5z"></path></svg>
              </div>
            </div>
          </div>
          <div class="a-cell xs-12 md-3" data-v-2b8789a2="">
            <div class="axop9d4ghf_ZiU7FQc-M8 baseselect-wrapper _2u25sfWmf6NUCbJ_StTs_r" data-v-2b8789a2=""><!---->
                <button  type="submit" class="btn btn-primary btn-sm" id="submit">Search</button>
            </div>
          </div>
        </div>
      </div>

     </form>
      <div class="items-sorting">
            <div class="row clearfix">
                <div class="results-column col-md-6 col-sm-6 col-xs-12">
                    <h4>Sorting</h4>
                </div>
                <div class="select-column pull-right col-md-3 col-sm-4 col-xs-12">
                    <div class="form-group">
                        <select id="simlock" onchange="sortList(this)" name="sort" class="_3Iq8JGYZpyTj97wvi5Wyu7 eUlOsp7XbB9G1L8SEMMpU baseselect-field">
                            <option selected>Select Any Option....</option>
                            <option value="az">Alphabetical,A-Z</option>
                            <option value="za">Alphabetical,Z-A</option>
                            <option value="hl">Price,high to low</option>
                            <option value="lh">Price,low to high</option>
                            <option value="no">Date,new to old</option>
                            <option value="on">Date,old to new</option>

                          </select>
                    </div>
                </div>
            </div>
        </div>

    	<div class="row clearfix">
        <div class="col-md-3 sidebar-filter">
          <ul class="_1PyjTAdMUxZV6zOWToeiGU">
            <li class="_2LiMhAnX4MDtEL5YEDIdLy">
                <span class="_2RGsPtNo">Price</span>
                  <div id="slider-container"></div>
                      <p>
                        <label for="amount">Price range:</label>
                        <br>
                        <input type="text" id="amount" style="border: 0; color: #00bfa5; font-weight: bold;" />
                      </p>

                      <div id="slider-range"></div>
                   </li>

            <li class="_2LiMhAnX4MDtEL5YEDIdLy">
              <h3 class="_2RGsPtNo">Category</h3>
              <ul data-test="filters-facet" class="_26WV8o_nAH1VuLftdiS-6t">
                <?php $__currentLoopData = CityClass::accessCategory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U"><div>
                    <input id="<?php echo e($category->id); ?>" name="category" type="checkbox" data-test="facet-<?php echo e($category->category); ?>" class="_3wvnh-Qn getCategory" value="<?php echo e($category->id); ?>" onclick="getCategories()">
                     <label for="<?php echo e($category->id); ?>" class="_33K8eTZu"><div class="_3S4CObWg"><div class="_2OVE0h6V"></div> <div class="_3xAYCg9N"><svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg"><path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg></div></div> <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                   <?php echo e($category->category); ?>

                </span> </span></div> <!----> <!----></label></div></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </ul>
            </li>


        </div>
        <div class="col-md-9">
          <div class="row" id="filter">

            <!--Shop Item-->
            <?php $__currentLoopData = CityClass::accessory(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <?php
                 $model = App\Models\Pmodel::where('id',$accessory->model_id)->first();
                 $imag = App\Models\AccessoryImage::where('accessory_id',$accessory->id)->first();
             ?>
            <div class="shop-item col-md-4 col-sm-6 col-xs-12">
                <div class="inner-box">
                    <?php if(Auth::user()): ?>

                    <?php if(CityClass::accessWishlist($accessory->id) == "1"): ?>
                    <a href="#" onclick="undoWishlist(<?php echo e($accessory->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#ff0707"></i></a>
                    <?php else: ?>
                    <a href="#" onclick="wishlist(<?php echo e($accessory->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#adadad"></i></a>
                    <?php endif; ?>
                  <?php else: ?>
                  <a href="#" onclick="wishlist(<?php echo e($accessory->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#adadad"></i></a>
                 <?php endif; ?>
                    <figure class="image-box">
                        <a href="<?php echo e(route('accessory.single',$accessory->id)); ?>"><img src="<?php echo e(asset('/storage/accessories/images/'.$imag->images)); ?>" alt="" /></a>
                      </figure>
                      <!--Lower Content-->
                      <div class="lower-content">
                        <h3><a href=""><?php echo e($model->brand->brand_name); ?> <?php echo e($model->model_name); ?></a></h3>
                        <div> <span><?php echo e($accessory->category_id); ?> - <?php echo e($accessory->name); ?></span> </div>
                          <span>
                          
                          </span>
                          <div>Starting from</div>
                          <div class="price">
                          <strong>$<?php echo e($accessory->sell_price); ?>.00</strong> <del>$<?php echo e($accessory->orig_price); ?>.00</del></div>
                          <!-- <a href="<?php echo e(url('single')); ?>" class="cart-btn theme-btn btn-style-two">Add to cart</a> -->
                      </div>
                  </div>
              </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



          </div>
        </div>
      </div>

        <div class="text-center">
        	<!-- Styled Pagination -->
            <div class="styled-pagination">
                <ul>
                    <li><?php echo e(CityClass::accessory()->links('vendor.pagination.custom')); ?></li>

                </ul>
            </div>
        </div>

    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>

<script>
    function getCategories()
       {



                    var  getCategory = [];
                $(".getCategory").each(function(){
                    if($(this).is(":checked")){
                        getCategory.push($(this).val());
                    }
                });

                var getCategory = getCategory.toString();
                        console.log(getCategory);
                $.ajax({
                    url: "<?php echo e(url('getcategory')); ?>",
                    type:"get",
                    dataType:"html",
                    data:{getCategory:getCategory},

                    success:function(response){
                    console.log(response);
                    $('#filter').html(response);
                    //   $('#exampleModal'+id).modal('show');
                    },

                });

       }



    function getBrand(event){

           var id = $(event).val();
        //    alert(id);
       $.ajax({
        url: "<?php echo e(url('getAccessoryFilter')); ?>/"+id,
        type:"get",

        success:function(response){

            console.log(response);
          $('#showModel').html(response);

        },


       });

      }

      function getModel(event){

        var id = $(event).val();
        //    alert(id);
       $.ajax({
        url: "<?php echo e(url('getAccessoryModel')); ?>/"+id,
        type:"get",

        success:function(response){

            console.log(response);
          $('#showCategory').html(response);

        },


       });



      }

      $('#contactUsForm').on('submit',function(e){
        e.preventDefault();

        var _token = $('input[name="_token"]').val();

        var category_id = $("#category_id").val();
        var model_id = $("#model_id").val();
        var brand_id = $("#brand_id").val();

        $('#submit').html('Please Wait...');
        $("#submit"). attr("disabled", true);
        $.ajax({
        url: "<?php echo e(route('search.accessory')); ?>",
        type: "POST",
        data: {_token:_token,brand_id:brand_id,
            model_id:model_id,
            category_id:category_id
        },
        success: function( response ) {
            console.log(response);
        $('#filter').html(response);


        document.getElementById("contactUsForm").reset();
        }
        });

        });


      function wishlist(id)
      {
        //   alert(colorID);
        <?php if(!Auth::user()): ?>
          window.location.href = "../signin";
        <?php else: ?>
        $.ajax({
            type:"get",
            url: "<?php echo e(url('accessory-wishlist')); ?>/"+id,

            success:function(wishlist)
            {
               window.location.reload();
               alert('Successfully add into your wishlist !');

            },error:function(error){
               console.log(error);
            }

            });
        <?php endif; ?>

      }

    function undoWishlist(id)
    {
        <?php if(!Auth::user()): ?>
          window.location.href = "../signin";
        <?php else: ?>
        $.ajax({
            type:"get",
            url: "<?php echo e(url('undo-access-wishlist')); ?>/"+id,

            success:function(wishlist)
            {
               window.location.reload();
            //    alert('Successfully Re into your wishlist !');

            },error:function(error){
               console.log(error);
            }

            });
        <?php endif; ?>
    }


</script>

<script>
    $(function() {
        $('#slider-container').slider({
            range: true,
            min: 0,
            max: 1000,
            values: [0, 1000],
            slide: function(event, ui) {
                $( "#amount" ).val( "$" + ui.values[ 0 ] + " - $" + ui.values[ 1 ] );
                var mi = ui.values[ 0 ];
                var mx = ui.values[ 1 ];
                filterSystem(mi, mx);

            }
        });
      $( "#amount" ).val( "$" + $( "#slider-range" ).slider( "values", 0 ) +
      " - $" + $( "#slider-range" ).slider( "values", 1 ) );

  });

function filterSystem(minPrice, maxPrice) {
    console.log(minPrice, maxPrice);

            $.ajax({
                url: "<?php echo e(url('getPriceFilter')); ?>",
                type:"get",
                dataType:"html",
                data:{minPrice:minPrice,maxPrice:maxPrice},
                success:function(response){
                console.log(response);
                $('#filter').html(response);
                //   $('#exampleModal'+id).modal('show');
                },

            });

	$("#computers div.system").hide().filter(function() {

		var price = parseInt($(this).data("price"), 10);

        return price >= minPrice && price <= maxPrice;

	}).show();
}


</script>

<script>

 function sortList(event)
 {
     var sort = $(event).val();
    //    alert(sort);
    //  if(sort == 'az')
    //  {
        $.ajax({
                url: "<?php echo e(url('getSortList')); ?>",
                type:"get",
                dataType:"html",
                data:{sort:sort},
                success:function(response){
                console.log(response);
                $('#filter').html(response);
                //   $('#exampleModal'+id).modal('show');
                },

            });
    //  }
 }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\cellCity\resources\views/frontend/buy-accessories.blade.php ENDPATH**/ ?>