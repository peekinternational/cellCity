<?php $__env->startSection('title'); ?> Orders <?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
<style>
    .loader {
      border: 16px solid #f3f3f3;
      border-radius: 50%;
      border-top: 16px solid #3498db;
      width: 100px;
      height: 100px;
      -webkit-animation: spin 2s linear infinite; /* Safari */
      animation: spin 2s linear infinite;
    }

    /* Safari */
    @-webkit-keyframes spin {
      0% { -webkit-transform: rotate(0deg); }
      100% { -webkit-transform: rotate(360deg); }
    }

    @keyframes  spin {
      0% { transform: rotate(0deg); }
      100% { transform: rotate(360deg); }
    }
    </style>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Orders <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?> Repair <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?> Orders <?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>


                        <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row mb-2">
                                            
                                            
                                            <div id="loader" class="loader justify-content-center" style="display: none; margin: auto;
                                            padding: 10px;">

                                            </div>
                                        </div>

                                        <div class="table-responsive">
                                            <table class="table table-centered table-nowrap" id="example3">
                                                <thead class="thead-light">
                                                    <tr>

                                                        <th>Order ID</th>
                                                        <th>Order Created</th>
                                                        <th>Billing Name</th>
                                                        <th>Date & Time</th>
                                                        <th>Total</th>
                                                        
                                                         <th>Status</th>
                                                        <th>Technician</th>

                                                        <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php $__currentLoopData = $RepairOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><a href="javascript: void(0);" class="text-body font-weight-bold"><?php echo e($order->id); ?></a> </td>
                                                        <td><?php echo e($order->created_at->format('Y-m-d')); ?></td>
                                                        <td><?php echo e($order->name); ?></td>
                                                        <td>
                                                            <?php echo e($order->date); ?>, <?php echo e($order->time); ?>

                                                        </td>

                                                        <td>
                                                           $<?php echo e($order->repairorderstypes->sum('price')); ?>

                                                        </td>
                                                         
                                                        <?php
                                                          $techId = App\Models\User::where('id',$order->techId)->first();
                                                        ?>
                                                       <td>
                                                        <?php if($order->order_status == 3 && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-warning">Assign</span>

                                                        <?php elseif($order->order_status == 1  && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-warning">Accept</span>
                                                        <?php elseif($order->order_status == 0  && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-secondary">Pendding</span>
                                                        <?php elseif($order->order_status == 2  && $order->techId == null): ?>
                                                        <span class="badge badge-pill badge-danger">Reject</span>
                                                        <?php elseif($order->order_status == 4 && $order->techId !== null): ?>
                                                        <span class="badge badge-pill badge-success">Completed</span>
                                                        <?php else: ?>
                                                        <span class="badge badge-pill badge-info">Not Assign</span>
                                                        <?php endif; ?>
                                                       </td>
                                                        <td id="or<?php echo e($order->id); ?>">
                                                          <?php if($order->techId === null || $order->techId === 0): ?>
                                                          <select onchange="selectTech(this,'<?php echo e($order->id); ?>')" class="form-control select2">
                                                            <option selected="">Select Technician</option>

                                                            <?php $__currentLoopData = CityClass::allTech(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tech): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <option value="<?php echo e($tech->id); ?>"><?php echo e($tech->name); ?></option>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                        </select>
                                                          <?php elseif($order->order_status == 3 && $order->techId !== null): ?>
                                                          <?php echo e($techId->name ?? 'Deleted Tech'); ?>

                                                           <button onclick="rejectOrder('<?php echo e($order->id); ?>')" class="btn btn-primary btn-sm" data-toggle="tooltip" data-placement="top" title="" data-original-title="Cancel The order">cancel</button>
                                                             <?php else: ?>
                                                             <?php echo e($techId->name ?? 'Deleted Tech'); ?>


                                                           <?php endif; ?>

                                                        </td>
                                                        <td>
                                                            <a href="javascript:void(0);" data-toggle="modal" data-target="#exampleModal<?php echo e($order->id); ?>" onclick="viewDetail('<?php echo e($order->id); ?>')" class="mr-3 text-success" data-toggle="tooltip" data-placement="top" title="" data-original-title="View Detail"><i class="mdi mdi-eye font-size-18"></i></a>
                                                            <a href="<?php echo e(url('admin/modify-order',$order->id)); ?>" class="mr-3 text-primary" data-toggle="tooltip" data-placement="top" title="" data-original-title="Edit"><i class="mdi mdi-pencil font-size-18"></i></a>
                                                            <a href="<?php echo e(url('admin/delete-order',$order->id)); ?>" class="text-danger" data-toggle="tooltip" data-placement="top" title="" data-original-title="Delete"><i class="mdi mdi-close font-size-18"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                </tbody>
                                            </table>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- end row -->
                    </div> <!-- container-fluid -->
                </div>
                <!-- End Page-content -->

                <!-- Modal -->
                <div id="showModels"></div>




<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script type="text/javascript">
$(document).ready(function() {
   $('#example3').DataTable({
        "order": [[ 0, "desc" ]]
    });

} );
    function viewDetail(id){
   $.ajax({
        url: "<?php echo e(url('admin/repairTypes')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
          $('#exampleModal'+id).modal('show');
        },

       });
    }

    function selectTech(event,id){

        $("#loader").show();
    var value=$(event).val()
     let _token   = $('meta[name="csrf-token"]').attr('content');
        $.ajax({
        url: "<?php echo e(url('admin/assignTech')); ?>",
        type:"post",
        data:{
            orderId:id,
            techid:value,
            _token:_token
        },
        success:function(response){
        //   console.log(response);
        $("#loader").hide();
          window.location.reload();
        //   alert(response);
        //   $('#or'+id).empty();
        },

       });

    }

    function rejectOrder(id)
    {
        $.ajax({
        url: "<?php echo e(url('admin/rejectOrder')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);

         location.reload();
        //   alert(response);
        },

       });
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/repair-orders.blade.php ENDPATH**/ ?>