

<?php $__env->startSection('title'); ?> Technician Add <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Technician Add  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?><?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <div class="row">
                            <div class="col-12">
                                  <?php if(Session::has('message')): ?>
                              <div class="col-12">
                                  <?php echo Session::get('message'); ?>

                              </div>
                              <?php endif; ?>
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.techcreate')); ?>" method="post">
                                            <?php echo e(csrf_field()); ?>

                                        <div class="form-group row">
                                            <label for="example-text-input" class="col-md-2 col-form-label">Name</label>
                                            <div class="col-md-10">
                                                <input class="form-control" name="name" type="text" placeholder="Enter name" <?php if(old('name')): ?> value="<?php echo e(old('name')); ?>" <?php endif; ?>  name="name" id="example-text-input">
                                                <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label for="example-email-input" class="col-md-2 col-form-label">Email</label>
                                            <div class="col-md-10">
                                                <input class="form-control" name="email" type="email" <?php if(old('email')): ?> value="<?php echo e(old('email')); ?>" <?php endif; ?> placeholder="Enter email" id="example-email-input">
                                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                                            </div>
                                        </div>
                                        <div class="form-group row">
                                            <label for="example-search-input" class="col-md-2 col-form-label">Address</label>
                                            <div class="col-md-10">
                                                <input class="form-control" type="text" placeholder="Enter Address" <?php if(old('address')): ?> value="<?php echo e(old('address')); ?>" <?php endif; ?> name="address" id="example-search-input">
                                                <span class="text-danger"><?php echo e($errors->first('address')); ?></span>
                                            </div>
                                        </div>
                                         <div class="form-group row">
                                            <label for="example-tel-input" class="col-md-2 col-form-label">Telephone</label>
                                            <div class="col-md-10">
                                                <input class="form-control" <?php if(old('phoneno')): ?> value="<?php echo e(old('phoneno')); ?>" <?php endif; ?> name="phoneno" type="tel" placeholder="Enter phone no" id="example-tel-input">
                                                <span class="text-danger"><?php echo e($errors->first('phoneno')); ?></span>
                                            </div>
                                        </div>

                                        <div class="form-group row">
                                            <label for="example-password-input" class="col-md-2 col-form-label">Password</label>
                                            <div class="col-md-10">
                                                <input class="form-control" name="password" type="password" placeholder="Enter password" id="example-password-input">
                                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                                            </div>
                                        </div>

                                        <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                    </div>

                                   </form>

                                    </div>
                                </div>
                            </div> <!-- end col -->

                        </div>
                        <!-- end row -->

                        <!-- end row -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/add-technician.blade.php ENDPATH**/ ?>