<?php $__env->startSection('styling'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--Page Title-->
    <section class="page-title" style="background-image: url(frontend-assets/images/background/3.jpg);">
      <div class="auto-container">
          <ul class="bread-crumb">
                <li><a href="index-2.html">Home</a></li>
                <li class="active">Cart List</li>
            </ul>
          <h1>Shop Detail</h1>
        </div>
    </section>

  <div class="container">
      <div class="row">
        <div class="col-md-12">
           <div class="card">
            <div class="product-stock bg-dark" style="margin-top: 100px"><i class="fa fa-info-circle"></i> <span id="quantity"></span> Product </div>
            <!-- Warenty Box -->
            <div class="warrenty-box">

                <?php
                if (Auth::check()) {
                     $userID = Auth::user()->id;
                     $items=\Cart::session($userID)->getContent();
                }
                else {
                    $collection=\Cart::getContent();
                }


                ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                           <tr>
                               <th>Product</th>
                               <th>Color</th>
                               <th>Storage</th>
                               <th>Condition</th>
                               <th>Quantity</th>
                               <th>Price</th>
                               <th>Total Price</th>
                               <th>Action</th>

                           </tr>
                         </thead>
                       <tbody>
                    <?php if(Auth::check()): ?>
                    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <?php if($item->attributes->category != "accessory"): ?>
                       <tr>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->attributes->color); ?></td>
                            <td><?php echo e($item->attributes->storage); ?></td>
                            <td><?php echo e($item->attributes->conditition); ?></td>
                            <td><input type="number" onfocus="removeval(<?php echo e($item->id); ?>)" class="form-control border-dark w-40px"
                            onchange="recal(<?php echo e($item->id); ?>)"id="change<?php echo e($item->id); ?>" value="<?php echo e($item->quantity); ?>"
                            MIN="1" />
                            </td>
                            <td><?php echo e($item->price); ?></td>
                            <?php
                                $total = round($item->quantity*$item->price);
                            ?>
                            <td><?php echo e($total); ?></td>

                            <td>
                                <div class="card-toolbar text-right">
                                    <form method="post">
                                        <?php echo csrf_field(); ?>
                                        <input type="hidden" value="" name="id">
                                        <a class="btn btn-danger" type="button" title="Delete"
                                            onclick="dlt(<?php echo e($item->id); ?>)"><i
                                                class="fa fa-trash"></i></a>
                                        
                                    </form>
                                </div>
                                </td>
                              </tr>
                                  <?php else: ?>

                                  <?php endif; ?>
                                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td colspan="7" class="text-center"><b>Your Product Cart is empty..</b></td>
                         <?php endif; ?>
                       <?php else: ?>

                       <?php $__empty_1 = true; $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                       <?php if($item->attributes->category != "accessory"): ?>
                          <tr>
                               <td><?php echo e($item->name); ?></td>
                               <td><?php echo e($item->attributes->color); ?></td>
                               <td><?php echo e($item->attributes->storage); ?></td>
                               <td><?php echo e($item->attributes->conditition); ?></td>
                               <td><input type="number" onfocus="removeval(<?php echo e($item->id); ?>)" class="form-control border-dark w-40px"
                               onchange="recal(<?php echo e($item->id); ?>)"id="change<?php echo e($item->id); ?>" value="<?php echo e($item->quantity); ?>"
                               MIN="1" />
                               </td>
                               <td><?php echo e($item->price); ?></td>
                               <?php
                                   $total = round($item->quantity*$item->price);
                               ?>
                               <td><?php echo e($total); ?></td>

                               <td>
                                   <div class="card-toolbar text-right">
                                       <form method="post">
                                           <?php echo csrf_field(); ?>
                                           <input type="hidden" value="" name="id">
                                           <a class="btn btn-danger" type="button" title="Delete"
                                               onclick="dlt(<?php echo e($item->id); ?>)"><i
                                                   class="fa fa-trash"></i></a>
                                           
                                       </form>
                                   </div>
                               </td>
                          </tr>
                           <?php else: ?>

                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <td colspan="7" class="text-center"><b>Your Product Cart is empty..</b></td>
                       <?php endif; ?>
                       <?php endif; ?>
                  </tbody>
               </table>
                </div>

            </div>


            <div class="product-stock bg-dark" style="margin-top: 100px"><i class="fa fa-info-circle"></i> <span id="quantity"></span> Accessory </div>
            <!-- Warenty Box -->
            <div class="warrenty-box">


                <?php
                if (Auth::check()) {
                     $userID = Auth::user()->id;
                     $items=\Cart::session($userID)->getContent();
                }
                else {
                    $collection=\Cart::getContent();
                }


                ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                           <tr>
                               <th>Brand Name</th>


                               <th>Accessory Name</th>
                               <th>Category</th>
                               <th>Quantity</th>
                               <th>Price</th>
                               <th>Total Price</th>
                               <th>Action</th>

                           </tr>
                         </thead>
                       <tbody>

                        <?php if(Auth::check()): ?>


                       <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                       <?php if($item->attributes->category == "accessory"): ?>
                          <tr>
                               <td><?php echo e($item->name); ?></td>
                               <td><?php echo e($item->associatedModel->name); ?></td>
                               <td><?php echo e($item->associatedModel->category); ?></td>
                               
                               <td><input type="number" onfocus="removeval(<?php echo e($item->id); ?>)" class="form-control border-dark w-40px"
                               onchange="recal(<?php echo e($item->id); ?>)"id="change<?php echo e($item->id); ?>" value="<?php echo e($item->quantity); ?>"
                               MIN="1" />
                               </td>
                               <td><?php echo e($item->price); ?></td>
                               <?php
                                   $total = round($item->quantity*$item->price);
                               ?>
                               <td><?php echo e($total); ?></td>

                               <td>
                                   <div class="card-toolbar text-right">
                                       <form method="post">
                                           <?php echo csrf_field(); ?>
                                           <input type="hidden" value="" name="id">
                                           <a class="btn btn-danger" type="button" title="Delete"
                                               onclick="dlt(<?php echo e($item->id); ?>)"><i
                                                   class="fa fa-trash"></i></a>
                                           
                                       </form>
                                   </div>
                               </td>
                          </tr>
                           <?php else: ?>

                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <td colspan="7" class="text-center"><b>Your Accessory Cart is empty..</b></td>
                       <?php endif; ?>
                       <?php else: ?>
                       <?php $__empty_1 = true; $__currentLoopData = $collection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                       <?php if($item->attributes->category == "accessory"): ?>
                          <tr>
                               <td><?php echo e($item->name); ?></td>
                               <td><?php echo e($item->associatedModel->name); ?></td>
                               <td><?php echo e($item->associatedModel->accessoryCategory->category); ?></td>
                               
                               <td><input type="number" onfocus="removeval(<?php echo e($item->id); ?>)" class="form-control border-dark w-40px"
                               onchange="recal(<?php echo e($item->id); ?>)"id="change<?php echo e($item->id); ?>" value="<?php echo e($item->quantity); ?>"
                               MIN="1" />
                               </td>
                               <td>$<?php echo e($item->price); ?></td>
                               <?php
                                   $total = round($item->quantity*$item->price);
                               ?>
                               <td>$<?php echo e($total); ?></td>

                               <td>
                                   <div class="card-toolbar text-right">
                                       <form method="post">
                                           <?php echo csrf_field(); ?>
                                           <input type="hidden" value="" name="id">
                                           <a class="btn btn-danger" type="button" title="Delete"
                                               onclick="dlt(<?php echo e($item->id); ?>)"><i
                                                   class="fa fa-trash"></i></a>
                                           
                                       </form>
                                   </div>
                               </td>
                          </tr>
                           <?php else: ?>

                          <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <td colspan="7" class="text-center"><b>Your Accessory Cart is empty..</b></td>
                       <?php endif; ?>
                       <?php endif; ?>
                  </tbody>
               </table>
                </div>

            </div>

            <div class="warrenty-box">
                <div class="row">
                <div class="col-md-6" style=" margin-left: 16px;">

                    <label>Select Address</label>
                 <select class="form-control" onchange="getAddress(this)">
                   <option value="0"> Select Address</option>
                   <?php if(Auth::check()): ?>
                   <?php $__currentLoopData = CityClass::shippingAddress(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipAddress): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                   <option value="<?php echo e($shipAddress->id); ?>"><?php echo e($shipAddress->shipaddress); ?></option>
                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                   <?php else: ?>
                   <option>Fill below Address Info</option>
                   <?php endif; ?>

                </select>

            </div>
             </div>
             <div id="getAddress">
                <form action="<?php echo e(url('shippadd.create')); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="modal-body">


                            <div class="form-group">
                                <label>Full name</label>
                                <input type="text" name="name" class="form-control" placeholder="Full Name" required="">
                            </div>
                            <div class="form-group">
                                <label>Email</label>
                                <input type="email" name="email" class="form-control" placeholder="Full Email" required="">
                            </div>
                            <div class="form-group">
                                <label>Phone Number</label>
                                <input type="text" name="mobileNo" class="form-control" placeholder="Phone Number" required>
                            </div>
                            <div class="form-group">
                                <label>Address</label>
                                <input type="text" name="shipaddress" class="form-control" placeholder="Full address" required>
                            </div>
                            <div class="form-group">
                                <label>Street Address</label>
                                <input type="text" name="street_address" class="form-control"  placeholder="Street address" required>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>Country</label>
                                        <input type="text" name="country" placeholder="Country" class="form-control" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label>State</label>
                                        <input type="text" name="state" placeholder="State" class="form-control" required>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-6">
                                        <label>City</label>
                                        <input type="text" placeholder="City" name="city" class="form-control" required>
                                    </div>
                                    <div class="col-md-6">
                                        <label class="control-label">Zip Code</label>
                                        <input type="text" name="zipcode" placeholder="Zip Code" class="form-control" required>
                                    </div>
                                </div>
                            </div>

                    </div>
                    <div class="modal-footer">
                        
                        <button type="submit" class="btn btn-primary btn-style-one">Submit</button>
                    </div>
                    </form>
                  </div>
                </div>
        </div>

      </div>
    </div>
  </div>


        <?php $__env->stopSection(); ?>
        <?php $__env->startSection('script'); ?>
        <script>


        function recal(pid){
            // var _token = $('input[name="_token"]').val();
            // alert(pid);
            var id =pid;
            var value = $('#change'+id).val();
            $.ajax({
            type:"post",
            url: "<?php echo e(route('cart.update')); ?>",
            headers: {'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')},
            data:{id: pid, quantity:value},
            success: function(user)
            {
                window.location.reload();
            },error:function(error){
            console.log(error);
            }
            });
            }

            // function removeval(id){
            //     //  alert(id);
            //     $("#change"+id).removeVal('value');

            //     }

            function dlt(item){
            var _token = $('input[name="_token"]').val();
            $.ajax({
            type:"post",
            url: "<?php echo e(route('cart.remove')); ?>",
            data:{id: item, _token: _token},
            success: function(user)
            {
                window.location.reload();
            },error:function(error){
            console.log(error);
            }
            });
            }

        function getAddress(event)
        {
            var id = $(event).val();
            // alert(id);
            console.log(id);
            if(id==0)
            {
                $('#getAddress').reset();
            }

            $.ajax({
            url: "<?php echo e(url('getAddress')); ?>/"+id,
            type:"get",
            success:function(response){
             console.log(response);
            $('#getAddress').html(response);
            //   $('#exampleModal'+id).modal('show');
            },

           });


        }
         </script>


        <?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\cellCity\resources\views/frontend/viewCart.blade.php ENDPATH**/ ?>