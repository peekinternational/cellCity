
<div class="table-responsive">
    <table class="table table-centered table-nowrap">
        <thead>
            <tr>
            <th>images</th>
            <th>description</th>
            </tr>
        </thead>
        <tbody  style="display: flex">

            <?php $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>

                <td> <img src="<?php echo e(asset('/storage/accessories/images/'.$img->images)); ?> " width="60px" height="60px">  </td>

               </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <td><?php echo e($accessory->description); ?></td>

        </tbody>
    </table>
</div>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/accessories/viewAccessory.blade.php ENDPATH**/ ?>