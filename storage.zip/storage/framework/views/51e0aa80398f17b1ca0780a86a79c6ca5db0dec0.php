

<?php $__empty_1 = true; $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<li data-test="facet-item" class="_33pDOgQ80LhcEmJTGXNM3U">

    <input id="<?php echo e($model->id); ?>" type="checkbox" name="models_name" data-test="facet-<?php echo e($model->brand->brand_name ?? ''); ?>  <?php echo e($model->model_name ?? ''); ?>" class="_3wvnh-Qn  getModelId"  value="<?php echo e($model->id); ?>" onclick="getModels(<?php echo e($model->id); ?>)">
     <label for="<?php echo e($model->id); ?>" class="_33K8eTZu">
      <div class="_3S4CObWg">
         <div class="_2OVE0h6V"></div>
         <div class="_3xAYCg9N">
             <svg aria-hidden="true" fill="currentColor" height="20" viewBox="0 0 40 40" width="20" xmlns="http://www.w3.org/2000/svg">
              <path d="M18.43 25a1 1 0 01-.71-.29l-5.84-5.84a1 1 0 010-1.41 1 1 0 0 1 1.42 0l5.13 5.13 8.23-8.24a1 1 0 011.42 0 1 1 0 0 1 0 1.41l-8.95 9a1 1 0 01-.7.24z"></path> <!----></svg>
              </div>
          </div>
              <div class="TRSMTVTh"><span class="_28IelIKC"><span class="_28IelIKC _1LYyf7lOuywpdBWUdNvl1k">
                  <?php echo e(ucwords($model->brand->brand_name) ?? ''); ?>  <?php echo e(ucwords($model->model_name) ?? ''); ?>

              </span>
              </span>
          </div> <!----> <!---->
      </label>

</li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    Oop no Brand Model Yet!
<?php endif; ?>

<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/filterProduct/getModel.blade.php ENDPATH**/ ?>