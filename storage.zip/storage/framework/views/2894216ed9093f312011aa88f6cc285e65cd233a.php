

  <?php $__empty_1 = true; $__currentLoopData = $accessories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $accessory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <?php
      $model = App\Models\Pmodel::where('id',$accessory->model_id)->first();
      $imag = App\Models\AccessoryImage::where('accessory_id',$accessory->id)->first();
  ?>
 <div class="shop-item col-md-4 col-sm-6 col-xs-12">
     <div class="inner-box h-100">
         <?php if(Auth::user()): ?>

         <?php if(CityClass::accessWishlist($accessory->id) == "1"): ?>
         <a href="#" onclick="undoWishlist(<?php echo e($accessory->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#ff0707"></i></a>
         <?php else: ?>
         <a href="#" onclick="wishlist(<?php echo e($accessory->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#adadad"></i></a>
         <?php endif; ?>
       <?php else: ?>
       <a href="#" onclick="wishlist(<?php echo e($accessory->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#adadad"></i></a>
      <?php endif; ?>
         <figure class="image-box">
             <a href="<?php echo e(route('accessory.single',$accessory->id)); ?>"><img src="<?php echo e(asset('/storage/accessories/images/'.$imag->images)); ?>" alt="" /></a>
           </figure>
           <!--Lower Content-->
           <div class="lower-content">
             <h3><a href=""><?php echo e($model->brand->brand_name); ?> <?php echo e($model->model_name); ?></a></h3>
             <div> <span><?php echo e($accessory->category_id); ?> - <?php echo e($accessory->name); ?></span> </div>
               <span>
               
               </span>
               <div>Starting from</div>
               <div class="price">
               <strong>$<?php echo e($accessory->sell_price); ?>.00</strong> <del>$<?php echo e($accessory->orig_price); ?>.00</del></div>
               <!-- <a href="<?php echo e(url('single')); ?>" class="cart-btn theme-btn btn-style-two">Add to cart</a> -->
           </div>
       </div>
   </div>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
   <div><h3 class="text-center"><strong>No products match the current search.</strong></h3></div>
 <?php endif; ?>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/accessoryFilter/getCategory.blade.php ENDPATH**/ ?>