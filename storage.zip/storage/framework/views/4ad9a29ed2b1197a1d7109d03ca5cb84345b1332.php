
<?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<?php
// $color = App\Models\ProductColor::where('product_id',$product->id)->first();
// $storage = App\Models\ProductStorage::where('color_id',$color->id)->first();
$model = App\Models\Pmodel::where('id',$product->model_id)->first();
$image = App\Models\ProductImage::where('color_id',$product->color_id)->first();
// $condition = App\Models\ProductCondition::where('storage_id',$storage->id)->first();
?>

<div class="shop-item col-md-4 col-sm-6 col-xs-12">
<div class="inner-box">
    <?php if(Auth::user()): ?>

    <?php if(CityClass::checkWishlist($product->id) == "1"): ?>
    <a href="#" onclick="undoWishlist(<?php echo e($product->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;color:#ff0707"></i></a>
    <?php else: ?>
    <a href="#" onclick="wishlist(<?php echo e($product->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;"></i></a>
    <?php endif; ?>
  <?php else: ?>
  <a href="#" onclick="wishlist(<?php echo e($product->id); ?>)"><i class="fa fa-heart" style="font-size: 30px;"></i></a>
 <?php endif; ?>
  <figure class="image-box">
    <a href="<?php echo e(route('product.details',$product->id)); ?>"><img src="<?php echo e(asset('storage/images/products/'.$image->image ?? '' )); ?>" alt="" /></a>
  </figure>
  <!--Lower Content-->
  <div class="lower-content">
    <h3><a href=""><?php echo e($model->brand->brand_name); ?>  <?php echo e($model->model_name); ?> </a></h3>
    <div> <span><?php echo e($product->storage); ?> -<?php echo e($product->color_name); ?> - <?php echo e($product->locked); ?></span> </div>
      <span>
      Warranty: <?php echo e($product->warranty); ?>

      </span>
      <div class="brand-imgs">
          <div class="brand">
            <img src="<?php echo e(asset('frontend-assets/images/tmobile.svg')); ?>">
          </div>
          <div class="brand">
            <img src="<?php echo e(asset('frontend-assets/images/att.svg')); ?>">
          </div>
          <div class="brand">
            <img src="<?php echo e(asset('frontend-assets/images/verizon.svg')); ?>">
          </div>
        </div>
      <div>Condition: <strong><?php echo e($product->condition); ?></strong></div>
      <div class="price">
      <strong>$<?php echo e($product->price ?? ''); ?>.00</strong> <del>$<?php echo e($product->orig_price ?? ''); ?></del></div>
      <!-- <a href="" class="cart-btn theme-btn btn-style-two">Add to cart</a> -->
  </div>
</div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
<div class="text-center"><b>Oops! No Product In Stock</b></div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/filterProduct/getCondition.blade.php ENDPATH**/ ?>