

<?php $__env->startSection('title'); ?> Coupon Add <?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
   <?php $__env->startComponent('admin.common-components.breadcrumb'); ?>
         <?php $__env->slot('title'); ?> Coupon Add  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_1'); ?>  <?php $__env->endSlot(); ?>
         <?php $__env->slot('li_2'); ?><?php $__env->endSlot(); ?>
     <?php if (isset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f)): ?>
<?php $component = $__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f; ?>
<?php unset($__componentOriginaleacbd9c3649915688399ea04ff288a2dea83ef3f); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>

                        <div class="row">
                              <?php if(Session::has('message')): ?>
                              <div class="col-12">
                                  <?php echo Session::get('message'); ?>

                              </div>
                              <?php endif; ?>
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <form action="<?php echo e(route('admin.coupon.update',$coupon->id)); ?>" method="post" enctype="multipart/form-data">
                                            <?php echo e(csrf_field()); ?>

                                            <?php echo method_field('PUT'); ?>


                                            <div class="form-group row">
                                                <label for="example-text-input" class="col-md-2 col-form-label">Coupon Name</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" name="name" type="text" placeholder="Enter name" value="<?php echo e($coupon->name); ?>"  name="name" id="example-text-input">
                                                    <span class="text-danger"><?php echo e($errors->first('name')); ?></span>
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label">Coupon Code</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" placeholder="Enter Coupon Code" value="<?php echo e($coupon->code); ?>" name="code" id="example-search-input">
                                                    <span class="text-danger"><?php echo e($errors->first('code')); ?></span>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label"> Coupon Type</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" placeholder="Enter type" value="<?php echo e($coupon->type); ?>" name="type" id="example-search-input">
                                                    <span class="text-danger"><?php echo e($errors->first('orig_price')); ?></span>
                                                </div>
                                            </div>
                                            <div class="form-group row">
                                                <label for="example-search-input" class="col-md-2 col-form-label"> value</label>
                                                <div class="col-md-10">
                                                    <input class="form-control" type="text" placeholder="Enter value" value="<?php echo e($coupon->value); ?>" name="value" id="example-search-input">
                                                    <span class="text-danger"><?php echo e($errors->first('quantity')); ?></span>
                                                </div>
                                            </div>
                                             <div class="form-group row">
                                                <label for="example-tel-input" class="col-md-2 col-form-label">Description</label>
                                                <div class="col-md-10">
                                                    <textarea type="text" name="description" class="form-control" ><?php echo e($coupon->description); ?></textarea>
                                                    <span class="text-danger"><?php echo e($errors->first('description')); ?></span>
                                                </div>
                                            </div>
                                             <div class="form-group row">
                                                <label for="example-tel-input" class="col-md-2 col-form-label">Status</label>
                                                <div class="col-md-10">
                                                  <select name="status" class="form-control">
                                                    <option value="1"> Active </option>
                                                    <option value="0"> InActive </option>
                                                  </select>
                                                </div>
                                            </div>


                                        <div class="text-center mt-4">
                                        <button type="submit" class="btn btn-primary waves-effect waves-light">Save</button>
                                    </div>

                                   </form>

                                    </div>
                                </div>
                            </div> <!-- end col -->

                        </div>
                        <!-- end row -->

                        <!-- end row -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    $(function() {
$('.selectpic').select2();
});

</script>

<script>
    function getModel(event)
    {
        var id = $(event).val();
        $.ajax({
        url: "<?php echo e(url('admin/accessory/getModels')); ?>/"+id,
        type:"get",
        success:function(response){
          console.log(response);
          $('#showModels').html(response);
        },

       });
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/coupon/edit.blade.php ENDPATH**/ ?>