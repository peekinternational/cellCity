
<?php $__env->startSection('styling'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="signup-area ptb-60">
  <div class="container">
    <div class="row justify-content-center d-flex">
      <div class="col-md-6">
        <div class="login-with-credentials">
          <div class="row">
          <div class="section-title">
            <?php if(Session::has('message')): ?>
            <div class="alert alert-danger">
                <?php echo Session::get('message'); ?>

            </div>
            <?php endif; ?>
            <?php if(Session::has('status')): ?>
            <div class="alert alert-success">
                <?php echo Session::get('status'); ?>

            </div>
            <?php endif; ?>
            <div class="login-signup-header">

              <h2 class="text-center"><span class="dot"></span> Login</h2>
            </div>
           </div>
           <form class="login-form" method="post" action="<?php echo e(url('/signin')); ?>" id="login-form">
            <?php echo e(csrf_field()); ?>

            <div class="form-group">
              <label>EMAIL</label>
              <input type="email" class="form-control" placeholder="Enter your email" id="login-email" name="email" value="customer@gmail.com" required="">
            </div>
            <div class="form-group">
              <label>PASSWORD</label>
              <input type="password" class="form-control" placeholder="Enter your password" id="login-password" name="password" value="123456" required="">
            </div>
            <button type="submit" class="btn btn-primary bg-black">LOGIN</button>
            <div class="d-flex justify-content-between">
              <a class="forgot-password" href="<?php echo e(url('forget-password')); ?>" style="color: #000;">Forgot password?</a>
              <p>Don't have account?<a href="<?php echo e(url('signup')); ?>"> Signup</a></p>
            </div>

          </form>

        </div>
      </div>
    </div>
  </div>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/signin.blade.php ENDPATH**/ ?>