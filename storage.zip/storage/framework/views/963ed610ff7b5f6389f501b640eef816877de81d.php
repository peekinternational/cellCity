
        <?php echo $__env->yieldContent('css'); ?>

        <!-- App css -->
        <link href="<?php echo e(URL::asset('admin-assets/css/bootstrap-dark.min.css')); ?>" id="bootstrap-dark" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('admin-assets/css/bootstrap.min.css')); ?>" id="bootstrap-light" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('admin-assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
        <!-- <link href="<?php echo e(URL::asset('admin-assets/css/app-rtl.min.css')); ?>" id="app-rtl" rel="stylesheet" type="text/css" /> -->
        <link href="<?php echo e(URL::asset('admin-assets/css/app-dark.min.css')); ?>" id="app-dark" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(URL::asset('admin-assets/css/app.min.css')); ?>" id="app-light" rel="stylesheet" type="text/css" />
         <link href="<?php echo e(URL::asset('admin-assets/css/select2.min.css')); ?>" id="app-light" rel="stylesheet" type="text/css" />

         <link href="<?php echo e(asset('admin-assets/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet" />
         <link href="<?php echo e(asset('admin-assets/datatable/jquery.dataTables.min.css')); ?>" rel="stylesheet" />
        
        <!-- <link href="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"> -->
      
        



<?php /**PATH C:\xampp\htdocs\cellCity\resources\views/admin/layouts/head.blade.php ENDPATH**/ ?>