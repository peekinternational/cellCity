<?php $__env->startSection('styling'); ?>
<style>
	.header-style-three .main-menu .navigation > li > a {
    padding: 15px 0px;
    padding-right: 0px;
    font-size: 14px;
    font-weight: 700;
    color: #fff;
    line-height: 20px;
}

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<!--Main Slider-->
<section class="main-slider">

    <div class="tp-banner-container">
        <div class="tp-banner">
            <ul>

                <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('frontend-assets/images/main-slider/2.jpg')); ?>"  data-saveperformance="off"  data-title="Awesome Title Here">
                <img src="<?php echo e(asset('frontend-assets/images/main-slider/2.jpg')); ?>"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">

                <!--Overlay-->
                <div class="overlay-style-one"></div>

                <div class="tp-caption sfl sfb tp-resizeme"
                data-x="left" data-hoffset="15"
                data-y="center" data-voffset="-50"
                data-speed="1500"
                data-start="0"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn">
                <div class="slider-logo">
                	<!-- <img src="<?php echo e(asset('frontend-assets/images/logo1.png')); ?>" alt="" title="Cell City"> -->
                </div>
                <h2>Repair <span>your</span><br>Mobile Phone</h2></div>

                <!-- <div class="tp-caption sfl sfb tp-resizeme"
                data-x="left" data-hoffset="15"
                data-y="center" data-voffset="50"
                data-speed="1500"
                data-start="500"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn"><div class="text">We offer repair many different types of devices including smartphones,<br> tablets etc...</div></div> --><br>

                <div class="tp-caption sfl sfb tp-resizeme"
                data-x="left" data-hoffset="15"
                data-y="center" data-voffset="130"
                data-speed="1500"
                data-start="1000"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn"><a href="<?php echo e(url('repair')); ?>" class="theme-btn btn-style-one">Repair Device</a></div>

                </li>

                <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('frontend-assets/images/main-slider/4.jpg')); ?>"  data-saveperformance="off"  data-title="Awesome Title Here">
                <img src="<?php echo e(asset('frontend-assets/images/main-slider/4.jpg')); ?>"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">

                <!--Overlay-->
                <div class="overlay-style-two"></div>

                <div class="tp-caption sft sfb tp-resizeme"
                data-x="left" data-hoffset="15"
                data-y="center" data-voffset="-50"
                data-speed="1500"
                data-start="0"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn">
                <div class="slider-logo">
                	<!-- <img src="<?php echo e(asset('frontend-assets/images/logo1.png')); ?>" alt="" title="Cell City"> -->
                </div>
                <h2 class="text-uppercase">Buy <span> Mobile Phone </span><br>of your Choice</h2></div>
                <br>
                <!-- <div class="tp-caption sfb sfb tp-resizeme"
                data-x="left" data-hoffset="15"
                data-y="center" data-voffset="30"
                data-speed="1500"
                data-start="500"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn"><div class="text text-left">Lorem ipsum dolor sit amet, consectetur adipisicing elit,<br> sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim <br></div></div> -->
                <br><br><br>
                <div class="tp-caption sfb sfb tp-resizeme"
                data-x="left" data-hoffset="15"
                data-y="center" data-voffset="100"
                data-speed="1500"
                data-start="1000"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn"><a href="<?php echo e(url('buy-phone')); ?>" class="theme-btn btn-style-one">Buy Phone</a></div>

                </li>

                <li data-transition="fade" data-slotamount="1" data-masterspeed="1000" data-thumb="<?php echo e(asset('frontend-assets/images/main-slider/6.png')); ?>"  data-saveperformance="off"  data-title="Awesome Title Here">
                <img src="<?php echo e(asset('frontend-assets/images/main-slider/6.png')); ?>"  alt=""  data-bgposition="center top" data-bgfit="cover" data-bgrepeat="no-repeat">

                <div class="tp-caption sfr sfb tp-resizeme"
                data-x="left" data-hoffset="-15"
                data-y="center" data-voffset="-50"
                data-speed="1500"
                data-start="0"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn">
                <div class="slider-logo">
                	<!-- <img src="<?php echo e(asset('frontend-assets/images/logo1.png')); ?>" alt="" title="Cell City"> -->
                </div>
                <h2 class="computer-problem">Pay Your<br><span>Bills</span> </h2></div>

                <!-- <div class="tp-caption sfr sfb tp-resizeme"
                data-x="left" data-hoffset="-15"
                data-y="center" data-voffset="50"
                data-speed="1500"
                data-start="500"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn"><div class="offer text-left">Lorem ipsum dolor sit amet, consectetur adipisicing elit, <br> sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam</div></div> -->
                <br>
                <div class="tp-caption sfr sfb tp-resizeme"
                data-x="left" data-hoffset="-15"
                data-y="center" data-voffset="130"
                data-speed="1500"
                data-start="1000"
                data-easing="easeOutExpo"
                data-splitin="none"
                data-splitout="none"
                data-elementdelay="0.01"
                data-endelementdelay="0.3"
                data-endspeed="1200"
                data-endeasing="Power4.easeIn">
                <!-- <a href="#" class="theme-btn btn-style-two">GET A QUOTE</a> &ensp;&ensp; -->
                 <a href="#" class="theme-btn btn-style-one">Pay Bills</a></div>


                </li>
            </ul>

        	<div class="tp-bannertimer"></div>
        </div>
    </div>
</section>
<!--Repair Section-->
    <section class="repair-section box-section">
    	<div class="auto-container">

        	<!--Sec Title One-->
            <!-- <div class="sec-title-one">
                <h2>WE ARE CELL CITY PHONE REPAIR</h2>
                <div class="text">Overcome faithful endless salvation enlightenment salvation overcome pious merciful<br>ascetic madness holiest joy passion zarathustra suicide overcome snare.</div>
            </div> -->

        	<div class="row clearfix">

                <!--Services Block-->
                <div class="services-block col-md-3 col-sm-4 col-xs-4">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<!--Icon Box-->
                    	<a href="<?php echo e(url('repair')); ?>">
                    		<div class="icon-box">
	                      	<span class="icon flaticon-mobile"  style="color:#00bfa5"></span>
	                      </div>
	                      <h3>Phone Repairs</h3>
                    	</a>
                    </div>
                </div>

                <!--Services Block-->
                <div class="services-block col-md-3 col-sm-4 col-xs-4">
                	<div class="inner-box wow fadeIn" data-wow-delay="300ms" data-wow-duration="1500ms">
                    	<!-- <div class="big-letter">Q</div> -->
                    	<!--Icon Box-->
                    	<a href="<?php echo e(url('buy-phone')); ?>">
                  			<div class="icon-box">
                  		    <span class="icon flaticon-technology-2"   style="color:#00bfa5"></span>
                  		  </div>
                  		  <h3>Buy Phones</h3>
                    	</a>
                    </div>
                </div>

                <!--Services Block-->
                <div class="services-block col-md-3 col-sm-4 col-xs-4">
                	<div class="inner-box wow fadeIn" data-wow-delay="600ms" data-wow-duration="1500ms">
                    	<!-- <div class="big-letter">C</div> -->
                    	<!--Icon Box-->
                    	<a href="<?php echo e(url('pay-bills')); ?>">
                    			<div class="icon-box">
                    		    <span class="icon flaticon-technology-1" style="color:#00bfa5"></span>
                    		  </div>
                    		  <h3>Pay Bills</h3>
                    	</a>

                    </div>
                </div>

            </div>
        </div>
    </section>
    <!--Services Style Two-->
    <!--Shop Section-->
    <section class="shop-section">
    	<div class="auto-container">
        	<!--Section Title One-->
            <div class="sec-title-one">
                <h2>OUR SHOP</h2>
                <div class="text"> We have a phone for everyone</div>
            </div>

        	<div class="row clearfix">

            	<!--Shop Item-->
                <?php
                    $products = App\Models\Product::paginate(4);
                ?>
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                $color = App\Models\ProductColor::where('product_id',$product->id)->first();
                $storage = App\Models\ProductStorage::where('color_id',$color->id)->first();
                $model = App\Models\Pmodel::where('id',$product->model_id)->first();
                $image = App\Models\ProductImage::where('product_id',$product->id)->first();
                $condition = App\Models\ProductCondition::where('storage_id',$storage->id)->first();
                ?>
                <div class="shop-item col-md-3 col-sm-6 col-xs-12">
                	<div class="inner-box wow fadeIn" data-wow-delay="0ms" data-wow-duration="1500ms">
                    	<figure class="image-box">
                        	<a href="<?php echo e(route('product.details',$product->id)); ?>"><img src="<?php echo e(asset('storage/images/products/'.$image->image ?? '')); ?>" alt="" /></a>
                        </figure>
                        <!--Lower Content-->

                        <div class="lower-content">
                        	<h3><a href="<?php echo e(url('single')); ?>"><?php echo e($model->brand->brand_name  ?? ''); ?>  <?php echo e($model->model_name ?? ''); ?></a></h3>
                        	<div> <span><?php echo e($product->memory ?? ''); ?> - <?php echo e($color->color_name ?? ''); ?> - <?php echo e($product->locked ?? ''); ?></span> </div>
		                        <span>
		                        Warranty: <?php echo e($product->warranty ?? ''); ?>

		                        </span>
		                        <div>Starting from</div>
                            <div class="price">
                            <strong>$<?php echo e($condition->price ?? ''); ?>.00</strong> <del>$950.00</del></div>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
            <?php echo e($products->links('vendor.pagination.custom')); ?>

        </div>
    </section>
    <!--Testimonial Style Two-->
    <section class="testimonial-style-two">
    	<div class="auto-container">
        	<!--Section Title One-->
        	<div class="sec-title-one">
            	<h2>WHAT OUR CUSTOMERS SAID</h2>
                <div class="text"></div>
            </div>

        	<div class="testimonial-carousel">
            	<div class="testimonial-carousel-two">

                	<!--Testimonial Block-->
                    <div class="testimonial-block-two">
                    	<div class="inner-box">
                        	<!--Image Box-->
                            <div class="head-section">
                          	  <figure class="image-box">
                          	      <img src="<?php echo e(asset('frontend-assets/images/resource/testimonial-1.jpg')); ?>" alt="" />
                          	  </figure>
                          	  <div class="name-and-skill">
                          			<div class="name">John</div>
                          			<div class="skill">Technician</div>
                          		</div>
                            </div>
                            <div class="text">Hope ultimate truth insofar god salvation god. The Truth revaluation insofar suicide inexpedient gains ultimate. Joy faith convictions victorious passion ocean.</div>
                            <!--Designation-->
                            <div class="reviwer-section soft-body-text"><div class="reviwer">Adrienne | Los Angeles, CA</div><img class="b-lazy b-loaded" src="https://d7gh5vrfihrl.cloudfront.net/website/badges/stars.svg"></div>
                        </div>
                    </div>

                    <!--Testimonial Block-->
                    <div class="testimonial-block-two">
                    	<div class="inner-box">
                        	<!--Image Box-->
                            <div class="head-section">
                          	  <figure class="image-box">
                          	      <img src="<?php echo e(asset('frontend-assets/images/resource/testimonial-2.jpg')); ?>" alt="" />
                          	  </figure>
                          	  <div class="name-and-skill">
                          			<div class="name">John</div>
                          			<div class="skill">Technician</div>
                          		</div>
                            </div>
                            <div class="text">Hope ultimate truth insofar god salvation god. The Truth revaluation insofar suicide inexpedient gains ultimate. Joy faith convictions victorious passion ocean.</div>
                            <!--Designation-->
                            <div class="reviwer-section soft-body-text"><div class="reviwer">Adrienne | Los Angeles, CA</div><img class="b-lazy b-loaded" src="https://d7gh5vrfihrl.cloudfront.net/website/badges/stars.svg"></div>
                        </div>
                    </div>

                    <!--Testimonial Block-->
                    <div class="testimonial-block-two">
                    	<div class="inner-box">
                        	<!--Image Box-->
                            <div class="head-section">
                          	  <figure class="image-box">
                          	      <img src="<?php echo e(asset('frontend-assets/images/resource/testimonial-1.jpg')); ?>" alt="" />
                          	  </figure>
                          	  <div class="name-and-skill">
                          			<div class="name">John</div>
                          			<div class="skill">Technician</div>
                          		</div>
                            </div>
                            <div class="text">Hope ultimate truth insofar god salvation god. The Truth revaluation insofar suicide inexpedient gains ultimate. Joy faith convictions victorious passion ocean.</div>
                            <!--Designation-->
                            <div class="reviwer-section soft-body-text"><div class="reviwer">Adrienne | Los Angeles, CA</div><img class="b-lazy b-loaded" src="https://d7gh5vrfihrl.cloudfront.net/website/badges/stars.svg"></div>
                        </div>
                    </div>

                    <!--Testimonial Block-->
                    <div class="testimonial-block-two">
                    	<div class="inner-box">
                        	<!--Image Box-->
                            <div class="head-section">
                          	  <figure class="image-box">
                          	      <img src="<?php echo e(asset('frontend-assets/images/resource/testimonial-2.jpg')); ?>" alt="" />
                          	  </figure>
                          	  <div class="name-and-skill">
                          			<div class="name">John</div>
                          			<div class="skill">Technician</div>
                          		</div>
                            </div>
                            <div class="text">Hope ultimate truth insofar god salvation god. The Truth revaluation insofar suicide inexpedient gains ultimate. Joy faith convictions victorious passion ocean.</div>
                            <!--Designation-->
                            <div class="reviwer-section soft-body-text"><div class="reviwer">Adrienne | Los Angeles, CA</div><img class="b-lazy b-loaded" src="https://d7gh5vrfihrl.cloudfront.net/website/badges/stars.svg"></div>
                        </div>
                    </div>

                    <!--Testimonial Block-->
                    <div class="testimonial-block-two">
                    	<div class="inner-box">
                        	<!--Image Box-->
                            <div class="head-section">
                            	<figure class="image-box">
                                <img src="<?php echo e(asset('frontend-assets/images/resource/testimonial-1.jpg')); ?>" alt="" />
	                            </figure>
	                            <div class="name-and-skill">
	                          		<div class="name">John</div>
	                          		<div class="skill">Technician</div>
	                          	</div>
                            </div>
                            <div class="text">Hope ultimate truth insofar god salvation god. The Truth revaluation insofar suicide inexpedient gains ultimate. Joy faith convictions victorious passion ocean.</div>
                            <!--Designation-->
                            <div class="reviwer-section soft-body-text"><div class="reviwer">Adrienne | Los Angeles, CA</div><img class="b-lazy b-loaded" src="https://d7gh5vrfihrl.cloudfront.net/website/badges/stars.svg"></div>
                        </div>
                    </div>

                    <!--Testimonial Block-->
                    <div class="testimonial-block-two">
                    	<div class="inner-box">
                        	<!--Image Box-->
                            <div class="head-section">
                            	<figure class="image-box">
                                <img src="<?php echo e(asset('frontend-assets/images/resource/testimonial-2.jpg')); ?>" alt="" />
                            	</figure>
                            	<div class="name-and-skill">
                            		<div class="name">John</div>
                            		<div class="skill">Technician</div>
                            	</div>
                            </div>

                            <div class="text">Hope ultimate truth insofar god salvation god. The Truth revaluation insofar suicide inexpedient gains ultimate. Joy faith convictions victorious passion ocean.</div>
                            <!--Designation-->
                            <div class="reviwer-section soft-body-text"><div class="reviwer">Adrienne | Los Angeles, CA</div><img class="b-lazy b-loaded" src="https://d7gh5vrfihrl.cloudfront.net/website/badges/stars.svg"></div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section>
    <!-- Blog Section / Style Two -->
    <section class="blog-section">
    	<div class="auto-container">

        	<div class="sec-title-one">
                <h2>OUR BLOG</h2>
                <div class="text"><br></div>
            </div>

        	<div class="row clearfix blogs-carousel">
            	<!--News Block-->
                <?php $__currentLoopData = CityClass::allBlog(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


            	<div class="news-block style-two col-md-12 col-sm-12 col-xs-12">
                	<div class="inner-box">
                    	<!--Image Box-->
                    	<div class="image-box wow fadeInLeft" data-wow-delay="0ms" data-wow-duration="1500ms">
                    		<a href="<?php echo e(route('blog.single',$blog->id)); ?>"><img src="<?php echo e(asset($blog->image)); ?>" /></a>
                   		</div>
                        <!--Lower Content-->
                        <div class="lower-content">
                        	<h3><a href="<?php echo e(route('blog.single',$blog->id)); ?>"><?php echo e($blog->title); ?></a></h3>
                          <div class="text"><?php echo e($blog->desc); ?></div>
                          <ul class="list">
                              <li><span class="icon flaticon-business"></span> <?php echo e($blog->created_at->format('d F Y')); ?></li>
                          </ul>
                        </div>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>

    

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\cellCity\resources\views/frontend/index.blade.php ENDPATH**/ ?>